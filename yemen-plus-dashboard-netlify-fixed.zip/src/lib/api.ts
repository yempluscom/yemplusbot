import {
  Customer,
  Conversation,
  Message,
  RequestItem,
  DashboardStats,
  AnalyticsData,
  LeadStatus,
  RequestStatus,
  RequestPriority
} from '../types';

const API_BASE = '/api';

function getCustomHeaders(): Record<string, string> {
  const headers: Record<string, string> = {
    'Content-Type': 'application/json'
  };

  const authToken = sessionStorage.getItem('yemplus_auth_token') || localStorage.getItem('yemplus_auth_token');
  if (authToken) {
    headers['Authorization'] = `Bearer ${authToken}`;
  }

  return headers;
}

export const api = {
  // Authentication
  async login(identifier: string, password: string): Promise<{ success: boolean; token?: string; user?: any; error?: string }> {
    const res = await fetch(`${API_BASE}/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'same-origin',
      body: JSON.stringify({ email: identifier, username: identifier, password })
    });
    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.error || 'بيانات الدخول غير صحيحة');
    }
    if (data.token) {
      sessionStorage.setItem('yemplus_auth_token', data.token);
    }
    return data;
  },

  async getMe(): Promise<{ authenticated: boolean; user?: any }> {
    try {
      const res = await fetch(`${API_BASE}/auth/me`, {
        headers: getCustomHeaders(),
        credentials: 'same-origin'
      });
      if (!res.ok) return { authenticated: false };
      return res.json();
    } catch {
      return { authenticated: false };
    }
  },

  async logout(): Promise<void> {
    try {
      await fetch(`${API_BASE}/auth/logout`, {
        method: 'POST',
        headers: getCustomHeaders(),
        credentials: 'same-origin'
      });
    } finally {
      sessionStorage.removeItem('yemplus_auth_token');
      localStorage.removeItem('yemplus_auth_token');
    }
  },

  // Stats
  async getDashboardStats(): Promise<DashboardStats> {
    const res = await fetch(`${API_BASE}/dashboard/stats`, {
      headers: getCustomHeaders()
    });
    if (!res.ok) throw new Error('فشل جلب إحصائيات لوحة التحكم');
    return res.json();
  },

  // Customers
  async getCustomers(params?: { search?: string; service?: string; lead_status?: string; needs_human?: boolean }): Promise<Customer[]> {
    const query = new URLSearchParams();
    if (params?.search) query.append('search', params.search);
    if (params?.service) query.append('service', params.service);
    if (params?.lead_status) query.append('lead_status', params.lead_status);
    if (params?.needs_human) query.append('needs_human', '1');

    const res = await fetch(`${API_BASE}/customers?${query.toString()}`, {
      headers: getCustomHeaders()
    });
    if (!res.ok) throw new Error('فشل جلب قائمة العملاء');
    return res.json();
  },

  async getCustomer(id: number): Promise<Customer> {
    const res = await fetch(`${API_BASE}/customers/${id}`, {
      headers: getCustomHeaders()
    });
    if (!res.ok) throw new Error('فشل جلب بيانات العميل');
    return res.json();
  },

  async updateCustomer(id: number, data: Partial<Customer>): Promise<Customer> {
    const res = await fetch(`${API_BASE}/customers/${id}`, {
      method: 'PATCH',
      headers: getCustomHeaders(),
      body: JSON.stringify(data),
    });
    if (!res.ok) throw new Error('فشل تحديث بيانات العميل');
    return res.json();
  },

  async getCustomerConversations(id: number): Promise<Conversation[]> {
    const res = await fetch(`${API_BASE}/customers/${id}/conversations`, {
      headers: getCustomHeaders()
    });
    if (!res.ok) throw new Error('فشل جلب محادثات العميل');
    return res.json();
  },

  async getCustomerRequests(id: number): Promise<RequestItem[]> {
    const res = await fetch(`${API_BASE}/customers/${id}/requests`, {
      headers: getCustomHeaders()
    });
    if (!res.ok) throw new Error('فشل جلب طلبات العميل');
    return res.json();
  },

  // Conversations
  async getConversations(params?: { status?: string; search?: string }): Promise<Conversation[]> {
    const query = new URLSearchParams();
    if (params?.status) query.append('status', params.status);
    if (params?.search) query.append('search', params.search);

    const res = await fetch(`${API_BASE}/conversations?${query.toString()}`, {
      headers: getCustomHeaders()
    });
    if (!res.ok) throw new Error('فشل جلب المحادثات');
    return res.json();
  },

  async getConversation(id: number): Promise<Conversation> {
    const res = await fetch(`${API_BASE}/conversations/${id}`, {
      headers: getCustomHeaders()
    });
    if (!res.ok) throw new Error('فشل جلب المحادثة');
    return res.json();
  },

  async updateConversationStatus(id: number, status: 'bot' | 'human' | 'closed'): Promise<Conversation> {
    const res = await fetch(`${API_BASE}/conversations/${id}`, {
      method: 'PATCH',
      headers: getCustomHeaders(),
      body: JSON.stringify({ status }),
    });
    if (!res.ok) throw new Error('فشل تغيير حالة المحادثة');
    return res.json();
  },

  async getMessages(conversationId: number): Promise<Message[]> {
    try {
      const res = await fetch(`${API_BASE}/conversations/${conversationId}/messages`, {
        headers: getCustomHeaders()
      });
      if (!res.ok) return [];
      const data = await res.json();
      return Array.isArray(data) ? data : [];
    } catch {
      return [];
    }
  },

  async sendMessage(conversationId: number, message: string): Promise<{ success: boolean; sent_to_whatsapp?: boolean; whatsapp_error?: string; message: Message }> {
    const res = await fetch(`${API_BASE}/conversations/${conversationId}/messages`, {
      method: 'POST',
      headers: getCustomHeaders(),
      body: JSON.stringify({ message, text: message, content: message }),
    });
    if (!res.ok) throw new Error('فشل إرسال الرسالة');
    return res.json();
  },

  async triggerAiReply(conversationId: number): Promise<{ success: boolean; reply?: string; sent_to_whatsapp?: boolean; whatsapp_error?: string }> {
    const res = await fetch(`${API_BASE}/conversations/${conversationId}/ai-reply`, {
      method: 'POST',
      headers: getCustomHeaders()
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
      throw new Error(data?.error || data?.message || 'فشل توليد رد البوت التلقائي');
    }
    return data;
  },

  // Requests
  async getRequests(params?: { status?: RequestStatus; priority?: RequestPriority; search?: string }): Promise<RequestItem[]> {
    const query = new URLSearchParams();
    if (params?.status) query.append('status', params.status);
    if (params?.priority) query.append('priority', params.priority);
    if (params?.search) query.append('search', params.search);

    const res = await fetch(`${API_BASE}/requests?${query.toString()}`, {
      headers: getCustomHeaders()
    });
    if (!res.ok) throw new Error('فشل جلب الطلبات');
    return res.json();
  },

  async getRequest(id: number): Promise<RequestItem> {
    const res = await fetch(`${API_BASE}/requests/${id}`, {
      headers: getCustomHeaders()
    });
    if (!res.ok) throw new Error('فشل جلب تفاصيل الطلب');
    return res.json();
  },

  async updateRequest(id: number, data: Partial<RequestItem>): Promise<RequestItem> {
    const res = await fetch(`${API_BASE}/requests/${id}`, {
      method: 'PATCH',
      headers: getCustomHeaders(),
      body: JSON.stringify(data),
    });
    if (!res.ok) throw new Error('فشل تحديث الطلب');
    return res.json();
  },

  // Human Requests
  async getHumanRequests(): Promise<any[]> {
    const res = await fetch(`${API_BASE}/human-requests`, {
      headers: getCustomHeaders()
    });
    if (!res.ok) throw new Error('فشل جلب طلبات التدخل البشري');
    return res.json();
  },

  async resolveHumanRequest(customerId: number): Promise<{ success: boolean; message: string }> {
    const res = await fetch(`${API_BASE}/human-requests/${customerId}/resolve`, {
      method: 'POST',
      headers: getCustomHeaders(),
    });
    if (!res.ok) throw new Error('فشل حل طلب التدخل البشري');
    return res.json();
  },

  // Leads
  async getLeads(status?: LeadStatus): Promise<Customer[]> {
    const query = status ? `?status=${status}` : '';
    const res = await fetch(`${API_BASE}/leads${query}`, {
      headers: getCustomHeaders()
    });
    if (!res.ok) throw new Error('فشل جلب قائمة العملاء المحتملين');
    return res.json();
  },

  // Analytics
  async getAnalytics(): Promise<AnalyticsData> {
    const res = await fetch(`${API_BASE}/analytics`, {
      headers: getCustomHeaders()
    });
    if (!res.ok) throw new Error('فشل جلب التحليلات');
    return res.json();
  },

  async getWorkerStatus(): Promise<{
    workerUrl: string;
    isKeyConfigured: boolean;
    keyLength: number;
    keyPreview: string;
    isProductionReady: boolean;
  }> {
    const res = await fetch(`${API_BASE}/worker/status`, {
      headers: getCustomHeaders()
    });
    if (!res.ok) throw new Error('فشل جلب حالة الاتصال');
    return res.json();
  },

  async updateWorkerConfig(config: { worker_url?: string; dashboard_api_key?: string }): Promise<{
    success: boolean;
    message: string;
    workerUrl: string;
    isKeyConfigured: boolean;
    keyLength: number;
  }> {
    const res = await fetch(`${API_BASE}/worker/config`, {
      method: 'POST',
      headers: getCustomHeaders(),
      body: JSON.stringify(config)
    });
    if (!res.ok) throw new Error('فشل تحديث إعدادات الاتصال');
    return res.json();
  },

  async testWorkerConnection(params?: {
    custom_key?: string;
    custom_url?: string;
    save_runtime?: boolean;
  }): Promise<{
    success: boolean;
    message: string;
    status?: number;
    data?: any;
    error?: string;
    details?: string;
    solution?: string;
    workerUrl?: string;
    keyLength?: number;
    keyConfigured?: boolean;
  }> {
    try {
      const res = await fetch(`${API_BASE}/worker/ping`, {
        method: 'POST',
        headers: getCustomHeaders(),
        body: JSON.stringify(params || {})
      });

      const contentType = res.headers.get('content-type') || '';
      if (contentType.includes('application/json')) {
        return await res.json();
      }

      return {
        success: false,
        message: 'فشل الاتصال: استجاب الخادم بحالة غير متوقعة',
        error: `HTTP ${res.status}`
      };
    } catch (err: any) {
      return {
        success: false,
        message: 'فشل الاتصال بالخادم',
        error: err?.message || 'خطأ في الشبكة'
      };
    }
  }
};
