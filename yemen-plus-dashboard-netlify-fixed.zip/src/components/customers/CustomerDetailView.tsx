import React, { useState, useEffect } from 'react';
import { Customer, RequestItem, Conversation, Message } from '../../types';
import { api } from '../../lib/api';
import {
  User,
  Phone,
  Briefcase,
  Target,
  DollarSign,
  Clock,
  MessageSquare,
  ClipboardList,
  Sparkles,
  ArrowRight,
  CheckCircle2,
  ExternalLink,
  Edit3,
  Save,
  X,
  History,
  Send
} from 'lucide-react';
import { LeadBadge, RequestStatusBadge, PriorityBadge, HumanBadge, ConversationBadge } from '../ui/Badge';
import { Button } from '../ui/Button';
import { Skeleton } from '../ui/Skeleton';
import { EmptyState } from '../ui/EmptyState';

interface CustomerDetailViewProps {
  customer: Customer;
  onBack: () => void;
  onOpenConversation: (conversationId: number) => void;
  onCustomerUpdated: (updated: Customer) => void;
}

export const CustomerDetailView: React.FC<CustomerDetailViewProps> = ({
  customer,
  onBack,
  onOpenConversation,
  onCustomerUpdated,
}) => {
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [requests, setRequests] = useState<RequestItem[]>([]);
  const [messages, setMessages] = useState<Message[]>([]);
  const [selectedConvId, setSelectedConvId] = useState<number | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isEditing, setIsEditing] = useState(false);
  const [editForm, setEditForm] = useState<Partial<Customer>>({ ...customer });
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    loadCustomerData();
  }, [customer.id]);

  const loadCustomerData = async () => {
    setIsLoading(true);
    try {
      const [convs, reqs] = await Promise.all([
        api.getCustomerConversations(customer.id),
        api.getCustomerRequests(customer.id),
      ]);
      setConversations(convs);
      setRequests(reqs);

      if (convs.length > 0) {
        setSelectedConvId(convs[0].id);
        const msgs = await api.getMessages(convs[0].id);
        setMessages(msgs);
      }
    } catch (err) {
      console.error('Error loading customer details:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSelectConversation = async (convId: number) => {
    setSelectedConvId(convId);
    try {
      const msgs = await api.getMessages(convId);
      setMessages(msgs);
    } catch (err) {
      console.error('Error loading messages:', err);
    }
  };

  const handleSaveCustomer = async () => {
    setIsSaving(true);
    try {
      const updated = await api.updateCustomer(customer.id, editForm);
      onCustomerUpdated(updated);
      setIsEditing(false);
    } catch (err) {
      console.error('Error updating customer:', err);
    } finally {
      setIsSaving(false);
    }
  };

  const handleResolveHuman = async () => {
    try {
      await api.resolveHumanRequest(customer.id);
      const updated = { ...customer, needs_human: 0 };
      onCustomerUpdated(updated);
      setEditForm(updated);
    } catch (err) {
      console.error('Error resolving human request:', err);
    }
  };

  const cleanPhone = customer.phone.replace(/\D/g, '');
  const waUrl = `https://wa.me/${cleanPhone}`;

  return (
    <div className="space-y-5">
      {/* Top Bar with Back Button & Actions */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 p-4 sm:p-5 rounded-2xl bg-slate-900/90 border border-slate-800/90 backdrop-blur-xl">
        <div className="flex items-center gap-3">
          <button
            onClick={onBack}
            className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 hover:bg-slate-800 text-slate-300 hover:text-white transition-colors"
            title="العودة لقائمة العملاء"
          >
            <ArrowRight className="w-4 h-4" />
          </button>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h2 className="text-base sm:text-lg font-bold text-white">{customer.name || 'عميل واتساب'}</h2>
              <LeadBadge status={customer.lead_status || 'general'} />
              <HumanBadge needsHuman={customer.needs_human} />
            </div>
            <p className="text-xs text-slate-400 font-mono mt-0.5">
              معرف: #{customer.id} | واتساب: +{customer.phone}
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto">
          {Boolean(customer.needs_human) && (
            <Button
              variant="success"
              size="sm"
              onClick={handleResolveHuman}
              leftIcon={<CheckCircle2 className="w-3.5 h-3.5" />}
            >
              تم حل الطلب
            </Button>
          )}

          <a
            href={waUrl}
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-300 border border-emerald-500/30 text-xs font-semibold transition-colors"
          >
            <Phone className="w-3.5 h-3.5" />
            <span>محادثة واتساب</span>
            <ExternalLink className="w-3 h-3" />
          </a>

          {!isEditing ? (
            <Button
              variant="secondary"
              size="sm"
              onClick={() => {
                setEditForm({ ...customer });
                setIsEditing(true);
              }}
              leftIcon={<Edit3 className="w-3.5 h-3.5" />}
            >
              تعديل
            </Button>
          ) : (
            <div className="flex items-center gap-1.5">
              <Button
                variant="primary"
                size="sm"
                onClick={handleSaveCustomer}
                isLoading={isSaving}
                leftIcon={<Save className="w-3.5 h-3.5" />}
              >
                حفظ
              </Button>
              <button
                onClick={() => setIsEditing(false)}
                className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Grid: Left/Right Split */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* Customer & AI Extracted Project Specs (1 Column) */}
        <div className="space-y-5">
          {/* Card: Extracted Information */}
          <div className="p-5 rounded-2xl bg-slate-900/90 border border-slate-800/90 space-y-4 shadow-xl">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="font-bold text-sm text-white flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-emerald-400" />
                <span>بيانات المشروع المستخرجة (AI)</span>
              </h3>
              <span className="text-[11px] text-slate-400">تحديث تلقائي</span>
            </div>

            {isEditing ? (
              <div className="space-y-3 text-xs">
                <div>
                  <label className="block text-slate-400 mb-1">اسم العميل:</label>
                  <input
                    type="text"
                    value={editForm.name || ''}
                    onChange={(e) => setEditForm({ ...editForm, name: e.target.value })}
                    className="w-full p-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 mb-1">الخدمة المطلوبة:</label>
                  <input
                    type="text"
                    value={editForm.service || ''}
                    onChange={(e) => setEditForm({ ...editForm, service: e.target.value })}
                    className="w-full p-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 mb-1">نوع النشاط:</label>
                  <input
                    type="text"
                    value={editForm.business || ''}
                    onChange={(e) => setEditForm({ ...editForm, business: e.target.value })}
                    className="w-full p-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 mb-1">تفاصيل المشروع:</label>
                  <textarea
                    rows={2}
                    value={editForm.project || ''}
                    onChange={(e) => setEditForm({ ...editForm, project: e.target.value })}
                    className="w-full p-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 mb-1">الهدف من المشروع:</label>
                  <input
                    type="text"
                    value={editForm.goal || ''}
                    onChange={(e) => setEditForm({ ...editForm, goal: e.target.value })}
                    className="w-full p-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white"
                  />
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block text-slate-400 mb-1">الميزانية:</label>
                    <input
                      type="text"
                      value={editForm.budget || ''}
                      onChange={(e) => setEditForm({ ...editForm, budget: e.target.value })}
                      className="w-full p-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-400 mb-1">المدة / الموعد:</label>
                    <input
                      type="text"
                      value={editForm.timeline || ''}
                      onChange={(e) => setEditForm({ ...editForm, timeline: e.target.value })}
                      className="w-full p-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-slate-400 mb-1">تصنيف العميل:</label>
                  <select
                    value={editForm.lead_status || 'general'}
                    onChange={(e) => setEditForm({ ...editForm, lead_status: e.target.value as any })}
                    className="w-full p-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white"
                  >
                    <option value="hot">🔥 Hot (حار ومستعد للشراء)</option>
                    <option value="warm">⚡ Warm (مهتم ويستكشف)</option>
                    <option value="cold">❄️ Cold (اهتمام منخفض)</option>
                    <option value="general">🌐 General (عام)</option>
                  </select>
                </div>
              </div>
            ) : (
              <div className="space-y-3.5 text-xs">
                <div className="flex items-start gap-3">
                  <Briefcase className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <div>
                    <span className="text-slate-400 block text-[11px]">الخدمة والنشاط:</span>
                    <span className="text-white font-bold">{customer.service || 'غير محدد'}</span>
                    {customer.business && (
                      <span className="text-slate-300 block text-[11px] mt-0.5">
                        مجال العمل: {customer.business}
                      </span>
                    )}
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <Target className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
                  <div>
                    <span className="text-slate-400 block text-[11px]">الهدف من المشروع:</span>
                    <span className="text-slate-200">{customer.goal || 'لم يتم تحديده بعد'}</span>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <DollarSign className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                  <div>
                    <span className="text-slate-400 block text-[11px]">الميزانية المتوقعة:</span>
                    <span className="text-amber-300 font-semibold">{customer.budget || 'بانتظار العرض'}</span>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <Clock className="w-4 h-4 text-indigo-400 shrink-0 mt-0.5" />
                  <div>
                    <span className="text-slate-400 block text-[11px]">المدة الزمنية المطلوبة:</span>
                    <span className="text-slate-200">{customer.timeline || 'غير محدد'}</span>
                  </div>
                </div>

                {customer.project && (
                  <div className="pt-2 border-t border-slate-800">
                    <span className="text-slate-400 block text-[11px] mb-1">تفاصيل المشروع:</span>
                    <p className="text-slate-300 leading-relaxed bg-slate-950/80 p-3 rounded-xl border border-slate-800">
                      {customer.project}
                    </p>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>

        {/* Requests & Conversation Workspace (2 Columns) */}
        <div className="lg:col-span-2 space-y-5">
          {/* Requests Section */}
          <div className="p-5 rounded-2xl bg-slate-900/90 border border-slate-800/90 space-y-4 shadow-xl">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="font-bold text-sm text-white flex items-center gap-2">
                <ClipboardList className="w-4 h-4 text-cyan-400" />
                <span>طلبات هذا العميل ({requests.length})</span>
              </h3>
            </div>

            {requests.length > 0 ? (
              <div className="space-y-2.5">
                {requests.map((req) => (
                  <div
                    key={req.id}
                    className="p-3.5 rounded-xl bg-slate-950/80 border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                  >
                    <div className="space-y-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-bold text-xs text-white">{req.service_type || 'طلب خدمة'}</span>
                        <RequestStatusBadge status={req.status} size="sm" />
                        <PriorityBadge priority={req.priority} size="sm" />
                      </div>
                      <p className="text-xs text-slate-300">{req.details}</p>
                    </div>

                    <div className="text-[11px] text-slate-400 font-mono shrink-0">
                      {req.created_at ? new Date(req.created_at).toLocaleDateString('ar-YE') : ''}
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-xs text-slate-400 text-center py-4">لا توجد طلبات مسجلة بشكل منفصل لهذا العميل</p>
            )}
          </div>

          {/* Conversation History Section */}
          <div className="p-5 rounded-2xl bg-slate-900/90 border border-slate-800/90 space-y-4 shadow-xl">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="font-bold text-sm text-white flex items-center gap-2">
                <MessageSquare className="w-4 h-4 text-emerald-400" />
                <span>سجل المحادثات المباشرة</span>
              </h3>

              {conversations.length > 0 && (
                <button
                  onClick={() => onOpenConversation(conversations[0].id)}
                  className="text-xs text-emerald-400 hover:text-emerald-300 flex items-center gap-1 font-semibold"
                >
                  <span>فتح في مركز المحادثات</span>
                  <ExternalLink className="w-3 h-3" />
                </button>
              )}
            </div>

            {isLoading ? (
              <div className="space-y-3">
                <Skeleton className="h-12 w-full" />
                <Skeleton className="h-12 w-full" />
              </div>
            ) : messages.length > 0 ? (
              <div className="space-y-3 max-h-96 overflow-y-auto p-2">
                {messages.map((msg, i) => {
                  const isCustomer = msg.sender === 'customer';
                  return (
                    <div
                      key={i}
                      className={`flex flex-col ${isCustomer ? 'items-start' : 'items-end'}`}
                    >
                      <div className="flex items-center gap-1 text-[10px] text-slate-400 mb-1">
                        <span>{isCustomer ? customer.name || 'العميل' : 'المساعد (يمن بلاس)'}</span>
                      </div>
                      <div
                        className={`max-w-[85%] px-4 py-2 rounded-2xl text-xs leading-relaxed ${
                          isCustomer
                            ? 'bg-slate-800 text-slate-100 rounded-tr-none border border-slate-700'
                            : 'bg-emerald-950 text-emerald-100 rounded-tl-none border border-emerald-500/30'
                        }`}
                      >
                        <p className="whitespace-pre-wrap">{msg.message || (msg as any).text}</p>
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <p className="text-xs text-slate-400 text-center py-4">لا توجد رسائل مسجلة</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
