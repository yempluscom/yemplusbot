import React, { useState } from 'react';
import { Customer } from '../../types';
import {
  Search,
  Phone,
  Briefcase,
  ChevronLeft,
  MessageSquare,
  Users,
  Sparkles
} from 'lucide-react';
import { LeadBadge, HumanBadge } from '../ui/Badge';
import { EmptyState } from '../ui/EmptyState';

interface CustomerListProps {
  customers: Customer[];
  onSelectCustomer: (customer: Customer) => void;
  onOpenChat: (customerId: number) => void;
}

export const CustomerList: React.FC<CustomerListProps> = ({
  customers,
  onSelectCustomer,
  onOpenChat,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedService, setSelectedService] = useState('all');
  const [selectedLeadStatus, setSelectedLeadStatus] = useState('all');
  const [filterNeedsHuman, setFilterNeedsHuman] = useState(false);

  // Extract unique services
  const services = Array.from(
    new Set(customers.map((c) => c.service).filter(Boolean))
  ) as string[];

  const filtered = customers.filter((c) => {
    const matchesSearch =
      searchTerm === '' ||
      (c.name && c.name.toLowerCase().includes(searchTerm.toLowerCase())) ||
      c.phone.includes(searchTerm) ||
      (c.project && c.project.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (c.business && c.business.toLowerCase().includes(searchTerm.toLowerCase()));

    const matchesService = selectedService === 'all' || c.service === selectedService;
    const matchesLeadStatus = selectedLeadStatus === 'all' || c.lead_status === selectedLeadStatus;
    const matchesHuman = !filterNeedsHuman || c.needs_human === 1 || c.needs_human === true;

    return matchesSearch && matchesService && matchesLeadStatus && matchesHuman;
  });

  return (
    <div className="space-y-4">
      {/* Search & Filter Header */}
      <div className="p-4 sm:p-5 rounded-2xl bg-slate-900/90 border border-slate-800/90 backdrop-blur-xl flex flex-col md:flex-row items-center gap-3 justify-between">
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute right-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="بحث بالاسم، رقم الواتساب، المشروع، النشاط..."
            className="w-full pl-3 pr-10 py-2.5 rounded-xl bg-slate-950/80 border border-slate-700/80 text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 transition-colors"
          />
        </div>

        <div className="flex flex-wrap items-center gap-2 w-full md:w-auto">
          {/* Service Filter */}
          <select
            value={selectedService}
            onChange={(e) => setSelectedService(e.target.value)}
            className="py-2 px-3 rounded-xl bg-slate-950/80 border border-slate-700/80 text-xs text-slate-200 focus:outline-none focus:border-emerald-500"
          >
            <option value="all">جميع الخدمات</option>
            {services.map((s, idx) => (
              <option key={idx} value={s}>
                {s}
              </option>
            ))}
          </select>

          {/* Lead Status Filter */}
          <select
            value={selectedLeadStatus}
            onChange={(e) => setSelectedLeadStatus(e.target.value)}
            className="py-2 px-3 rounded-xl bg-slate-950/80 border border-slate-700/80 text-xs text-slate-200 focus:outline-none focus:border-emerald-500"
          >
            <option value="all">جميع التصنيفات</option>
            <option value="hot">🔥 عملاء حارين (Hot)</option>
            <option value="warm">⚡ عملاء مهتمين (Warm)</option>
            <option value="cold">❄️ اهتمام منخفض (Cold)</option>
            <option value="general">🌐 عام (General)</option>
          </select>

          {/* Needs Human Toggle Button */}
          <button
            type="button"
            onClick={() => setFilterNeedsHuman(!filterNeedsHuman)}
            className={`py-2 px-3 rounded-xl text-xs font-bold border transition-colors flex items-center gap-1.5 ${
              filterNeedsHuman
                ? 'bg-red-600 border-red-500 text-white shadow-md shadow-red-900/50'
                : 'bg-slate-950/80 border-slate-700/80 text-slate-300 hover:text-white'
            }`}
          >
            <span>🚨 يحتاج تدخل بشري</span>
          </button>
        </div>
      </div>

      {/* Customer Count Summary */}
      <div className="flex items-center justify-between text-xs text-slate-400 px-1">
        <span>
          عرض <strong className="text-white">{filtered.length}</strong> من إجمالي{' '}
          <strong className="text-white">{customers.length}</strong> عميل
        </span>
      </div>

      {/* Responsive View: Desktop Table + Mobile Cards */}
      {filtered.length > 0 ? (
        <>
          {/* Desktop Table View (md and above) */}
          <div className="hidden md:block rounded-2xl bg-slate-900/90 border border-slate-800/90 overflow-hidden shadow-xl backdrop-blur-xl">
            <div className="overflow-x-auto">
              <table className="w-full text-right text-xs">
                <thead className="bg-slate-950/80 border-b border-slate-800 text-slate-400 font-semibold">
                  <tr>
                    <th className="py-3.5 px-4">العميل</th>
                    <th className="py-3.5 px-4">الخدمة والنشاط</th>
                    <th className="py-3.5 px-4">التصنيف (Lead)</th>
                    <th className="py-3.5 px-4">ملخص المشروع والطلب</th>
                    <th className="py-3.5 px-4 text-center">الإجراءات</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 text-slate-300">
                  {filtered.map((customer) => (
                    <tr
                      key={customer.id}
                      onClick={() => onSelectCustomer(customer)}
                      className="hover:bg-slate-800/50 cursor-pointer transition-colors group"
                    >
                      {/* Name & Phone */}
                      <td className="py-3.5 px-4">
                        <div className="flex items-center gap-3">
                          <div className="w-9 h-9 rounded-xl bg-slate-800 text-emerald-400 font-bold text-xs flex items-center justify-center border border-slate-700 group-hover:border-emerald-500/50 transition-colors shrink-0">
                            {customer.name ? customer.name.slice(0, 2) : 'عم'}
                          </div>
                          <div>
                            <div className="font-bold text-white text-sm flex items-center gap-2">
                              <span>{customer.name || 'عميل واتساب'}</span>
                              <HumanBadge needsHuman={customer.needs_human} size="sm" />
                            </div>
                            <div className="flex items-center gap-1 text-[11px] text-slate-400 font-mono mt-0.5">
                              <Phone className="w-3 h-3 text-slate-500" />
                              <span>+{customer.phone}</span>
                            </div>
                          </div>
                        </div>
                      </td>

                      {/* Service & Business */}
                      <td className="py-3.5 px-4">
                        <div className="font-semibold text-emerald-400">{customer.service || 'غير محدد'}</div>
                        <div className="text-[11px] text-slate-400 truncate max-w-[150px]">
                          {customer.business || customer.activity || 'نشاط تجاري'}
                        </div>
                      </td>

                      {/* Lead Status */}
                      <td className="py-3.5 px-4">
                        <LeadBadge status={customer.lead_status || 'general'} size="md" />
                      </td>

                      {/* Project Summary */}
                      <td className="py-3.5 px-4 max-w-xs">
                        <div className="line-clamp-2 text-slate-300 text-xs leading-relaxed">
                          {customer.project || customer.summary || 'تم تسجيل العميل عبر منصة يمن بلاس'}
                        </div>
                      </td>

                      {/* Actions */}
                      <td className="py-3.5 px-4 text-center">
                        <div className="flex items-center justify-center gap-1.5" onClick={(e) => e.stopPropagation()}>
                          <button
                            onClick={() => onOpenChat(customer.id)}
                            className="p-2 rounded-xl bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-300 border border-emerald-500/30 transition-colors"
                            title="فتح المحادثة الفورية"
                          >
                            <MessageSquare className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => onSelectCustomer(customer)}
                            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 transition-colors"
                            title="عرض الملف والتفاصيل"
                          >
                            <ChevronLeft className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Mobile Cards View (< md) */}
          <div className="md:hidden space-y-3">
            {filtered.map((customer) => (
              <div
                key={customer.id}
                onClick={() => onSelectCustomer(customer)}
                className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800/90 space-y-3 shadow-lg active:scale-[0.99] transition-transform"
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-2.5">
                    <div className="w-9 h-9 rounded-xl bg-slate-800 text-emerald-400 font-bold text-xs flex items-center justify-center border border-slate-700">
                      {customer.name ? customer.name.slice(0, 2) : 'عم'}
                    </div>
                    <div>
                      <h4 className="font-bold text-sm text-white">{customer.name || 'عميل واتساب'}</h4>
                      <p className="text-[11px] text-slate-400 font-mono">+{customer.phone}</p>
                    </div>
                  </div>
                  <LeadBadge status={customer.lead_status || 'general'} size="sm" />
                </div>

                <div className="flex items-center justify-between text-xs pt-2 border-t border-slate-800/60">
                  <span className="text-emerald-400 font-semibold">{customer.service || 'خدمات يمن بلاس'}</span>
                  <HumanBadge needsHuman={customer.needs_human} size="sm" />
                </div>

                {customer.project && (
                  <p className="text-xs text-slate-300 line-clamp-2 bg-slate-950/60 p-2.5 rounded-xl border border-slate-800/60">
                    {customer.project}
                  </p>
                )}

                <div className="flex items-center justify-between pt-2 border-t border-slate-800/60 text-xs">
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onOpenChat(customer.id);
                    }}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-600/20 text-emerald-300 border border-emerald-500/30 font-medium"
                  >
                    <MessageSquare className="w-3.5 h-3.5" />
                    <span>المحادثة</span>
                  </button>
                  <div className="flex items-center gap-1 text-slate-400 text-[11px]">
                    <span>عرض التفاصيل</span>
                    <ChevronLeft className="w-3.5 h-3.5" />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </>
      ) : (
        <EmptyState
          icon={Users}
          title="لا يوجد عملاء مطابقين"
          description="لم يتم العثور على أي عميل يتطابق مع معايير البحث الحالية."
          actionLabel="مسح معايير البحث"
          onAction={() => {
            setSearchTerm('');
            setSelectedService('all');
            setSelectedLeadStatus('all');
            setFilterNeedsHuman(false);
          }}
        />
      )}
    </div>
  );
};
