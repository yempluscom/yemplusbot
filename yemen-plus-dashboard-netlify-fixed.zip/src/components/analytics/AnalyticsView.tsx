import React from 'react';
import { AnalyticsData } from '../../types';
import {
  TrendingUp,
  Users,
  MessageSquare,
  ClipboardList,
  Flame,
  Zap,
  Clock,
  ThumbsUp,
  Award,
  Sparkles,
  BarChart2
} from 'lucide-react';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Cell,
  CartesianGrid
} from 'recharts';

interface AnalyticsViewProps {
  data: AnalyticsData;
}

export const AnalyticsView: React.FC<AnalyticsViewProps> = ({ data }) => {
  const { summary, servicesDemand, dailyGrowth, leadFunnel, hourlyActivity } = data;

  const colors = ['#10b981', '#06b6d4', '#3b82f6', '#8b5cf6', '#f59e0b', '#f43f5e'];

  return (
    <div className="space-y-6">
      {/* 1. KPI Summary Strip */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3.5">
        <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>العملاء</span>
            <Users className="w-3.5 h-3.5 text-blue-400" />
          </div>
          <div className="text-xl font-extrabold text-white mt-1.5">{summary.totalCustomers}</div>
          <span className="text-[10px] text-emerald-400 mt-0.5 block">+18% هذا الشهر</span>
        </div>

        <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>المحادثات</span>
            <MessageSquare className="w-3.5 h-3.5 text-indigo-400" />
          </div>
          <div className="text-xl font-extrabold text-white mt-1.5">{summary.totalConversations}</div>
          <span className="text-[10px] text-indigo-400 mt-0.5 block">24/7 نشط</span>
        </div>

        <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>الطلبات المستخرجة</span>
            <ClipboardList className="w-3.5 h-3.5 text-cyan-400" />
          </div>
          <div className="text-xl font-extrabold text-white mt-1.5">{summary.totalRequests}</div>
          <span className="text-[10px] text-cyan-400 mt-0.5 block">AI Auto-Extraction</span>
        </div>

        <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>معدل التحويل</span>
            <TrendingUp className="w-3.5 h-3.5 text-emerald-400" />
          </div>
          <div className="text-xl font-extrabold text-emerald-400 mt-1.5">{summary.conversionRate}%</div>
          <span className="text-[10px] text-slate-400 mt-0.5 block">إلى عملاء مؤهلين</span>
        </div>

        <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>سرعة الرد الآلي</span>
            <Clock className="w-3.5 h-3.5 text-amber-400" />
          </div>
          <div className="text-xl font-extrabold text-white mt-1.5">{summary.avgResponseMinutes}s</div>
          <span className="text-[10px] text-amber-400 mt-0.5 block">استجابة فائقة السرعة</span>
        </div>

        <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>رضا العملاء</span>
            <ThumbsUp className="w-3.5 h-3.5 text-rose-400" />
          </div>
          <div className="text-xl font-extrabold text-white mt-1.5">{data.satisfactionRate}%</div>
          <span className="text-[10px] text-rose-400 mt-0.5 block">تقييم إيجابي</span>
        </div>
      </div>

      {/* 2. Charts Grid: Growth & Services */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Daily Growth Trend */}
        <div className="p-6 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-bold text-sm text-white flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-emerald-400" />
                <span>نمو وتأهيل العملاء اليومي</span>
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">مقارنة بين إجمالي العملاء والعملاء الحارين (Hot)</p>
            </div>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={dailyGrowth} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="growthCust" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.4} />
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="growthHot" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#f43f5e" stopOpacity={0.4} />
                    <stop offset="95%" stopColor="#f43f5e" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <XAxis dataKey="date" stroke="#64748b" fontSize={11} />
                <YAxis stroke="#64748b" fontSize={11} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#0f172a',
                    borderColor: '#334155',
                    borderRadius: '0.75rem',
                    fontSize: '12px',
                    color: '#fff',
                    direction: 'rtl'
                  }}
                />
                <Area type="monotone" dataKey="customers" name="عملاء جدد" stroke="#10b981" fill="url(#growthCust)" strokeWidth={2} />
                <Area type="monotone" dataKey="hotLeads" name="عملاء حارين (Hot)" stroke="#f43f5e" fill="url(#growthHot)" strokeWidth={2} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Services Demand Breakdown */}
        <div className="p-6 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-bold text-sm text-white flex items-center gap-2">
                <BarChart2 className="w-4 h-4 text-cyan-400" />
                <span>حجم الطلب حسب خدمات يمن بلاس</span>
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">عدد الطلبات وقيمتها التقديرية</p>
            </div>
          </div>

          <div className="space-y-3">
            {servicesDemand.map((item, idx) => (
              <div key={idx} className="p-2.5 rounded-xl bg-slate-950/70 border border-slate-800/80 flex items-center justify-between text-xs">
                <div className="flex items-center gap-2.5">
                  <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: colors[idx % colors.length] }} />
                  <span className="font-semibold text-white">{item.service}</span>
                </div>
                <div className="flex items-center gap-4">
                  <span className="text-slate-400">{item.count} طلب</span>
                  <span className="text-emerald-400 font-bold font-mono">{item.revenueEstimate}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* 3. Funnel & Hourly Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Sales Qualification Funnel */}
        <div className="p-6 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-4">
          <h3 className="font-bold text-sm text-white flex items-center gap-2">
            <Award className="w-4 h-4 text-amber-400" />
            <span>قمع تحويل العملاء والمبيعات (Sales Funnel)</span>
          </h3>

          <div className="space-y-3">
            {leadFunnel.map((step, idx) => (
              <div key={idx} className="space-y-1">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-medium text-slate-300">{step.stage}</span>
                  <span className="font-bold text-slate-400">{step.count} ({step.percentage}%)</span>
                </div>
                <div className="w-full h-2.5 rounded-full bg-slate-950 overflow-hidden border border-slate-800">
                  <div
                    className="h-full rounded-full bg-gradient-to-r from-emerald-500 to-teal-400 transition-all duration-500"
                    style={{ width: `${step.percentage}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Hourly Peak Activity */}
        <div className="p-6 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-4">
          <h3 className="font-bold text-sm text-white flex items-center gap-2">
            <Clock className="w-4 h-4 text-indigo-400" />
            <span>ساعات الذروة ونشاط الرسائل عبر اليوم</span>
          </h3>

          <div className="h-52 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={hourlyActivity} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <XAxis dataKey="hour" stroke="#64748b" fontSize={11} />
                <YAxis stroke="#64748b" fontSize={11} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#0f172a',
                    borderColor: '#334155',
                    borderRadius: '0.75rem',
                    fontSize: '12px',
                    color: '#fff',
                    direction: 'rtl'
                  }}
                />
                <Bar dataKey="messages" name="عدد الرسائل" fill="#6366f1" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
};
