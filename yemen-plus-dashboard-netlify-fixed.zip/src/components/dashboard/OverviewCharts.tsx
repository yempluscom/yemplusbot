import React from 'react';
import { DashboardStats } from '../../types';
import { BarChart3, PieChart, TrendingUp, Sparkles, CheckCircle } from 'lucide-react';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  BarChart,
  Bar,
  Cell
} from 'recharts';

interface OverviewChartsProps {
  stats: DashboardStats;
}

export const OverviewCharts: React.FC<OverviewChartsProps> = ({ stats }) => {
  const weeklyData = stats.weeklyTrends || [
    { day: 'السبت', customers: 4, requests: 3, humanRequests: 1 },
    { day: 'الأحد', customers: 6, requests: 5, humanRequests: 2 },
    { day: 'الإثنين', customers: 8, requests: 6, humanRequests: 1 },
    { day: 'الثلاثاء', customers: 7, requests: 4, humanRequests: 3 },
    { day: 'الأربعاء', customers: 9, requests: 8, humanRequests: 2 },
    { day: 'الخميس', customers: 11, requests: 9, humanRequests: 4 },
    { day: 'الجمعة', customers: 5, requests: 4, humanRequests: 1 },
  ];

  const colors = ['#10b981', '#06b6d4', '#3b82f6', '#8b5cf6', '#f59e0b', '#f43f5e'];

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      {/* 1. Weekly Trends Chart */}
      <div className="lg:col-span-2 p-6 rounded-2xl bg-slate-900/90 border border-slate-800 flex flex-col justify-between">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-emerald-400" />
              <span>نشاط المحادثات والطلبات الأسبوعي</span>
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">معدل دخول العملاء ورفع الطلبات عبر واتساب</p>
          </div>
          <div className="flex items-center gap-3 text-xs">
            <span className="flex items-center gap-1 text-emerald-400">
              <span className="w-2 h-2 rounded-full bg-emerald-500"></span> العملاء
            </span>
            <span className="flex items-center gap-1 text-cyan-400">
              <span className="w-2 h-2 rounded-full bg-cyan-500"></span> الطلبات
            </span>
          </div>
        </div>

        <div className="h-64 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={weeklyData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
              <defs>
                <linearGradient id="custColor" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#10b981" stopOpacity={0.4} />
                  <stop offset="95%" stopColor="#10b981" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="reqColor" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#06b6d4" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#06b6d4" stopOpacity={0} />
                </linearGradient>
              </defs>
              <XAxis dataKey="day" stroke="#64748b" fontSize={12} tickLine={false} />
              <YAxis stroke="#64748b" fontSize={12} tickLine={false} />
              <Tooltip
                contentStyle={{
                  backgroundColor: '#0f172a',
                  borderColor: '#334155',
                  borderRadius: '0.75rem',
                  fontSize: '12px',
                  color: '#fff',
                  direction: 'rtl'
                }}
              />
              <Area type="monotone" dataKey="customers" name="عملاء جدد" stroke="#10b981" strokeWidth={2} fillOpacity={1} fill="url(#custColor)" />
              <Area type="monotone" dataKey="requests" name="طلبات جديدة" stroke="#06b6d4" strokeWidth={2} fillOpacity={1} fill="url(#reqColor)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* 2. Most Requested Services */}
      <div className="p-6 rounded-2xl bg-slate-900/90 border border-slate-800 flex flex-col justify-between">
        <div>
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-cyan-400" />
              <span>أكثر الخدمات طلبًا</span>
            </h3>
            <span className="text-xs text-slate-400">حسب استخراج AI</span>
          </div>

          <div className="space-y-3.5">
            {stats.servicesBreakdown && stats.servicesBreakdown.length > 0 ? (
              stats.servicesBreakdown.map((item, idx) => (
                <div key={idx} className="space-y-1.5">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-medium text-slate-200 truncate max-w-[180px]">{item.service}</span>
                    <span className="font-bold text-slate-400">{item.count} طلب ({item.percentage}%)</span>
                  </div>
                  <div className="w-full h-2 rounded-full bg-slate-800 overflow-hidden">
                    <div
                      className="h-full rounded-full transition-all duration-500"
                      style={{
                        width: `${Math.max(item.percentage, 8)}%`,
                        backgroundColor: colors[idx % colors.length]
                      }}
                    />
                  </div>
                </div>
              ))
            ) : (
              <div className="text-center py-8 text-slate-400 text-xs">
                لا توجد بيانات خدمات مسجلة بعد
              </div>
            )}
          </div>
        </div>

        <div className="mt-4 pt-4 border-t border-slate-800/80 flex items-center justify-between text-xs text-slate-400">
          <span>يمن بلاس - حلول وخدمات رقمية</span>
          <span className="text-emerald-400 font-semibold">18 خدمة متكاملة</span>
        </div>
      </div>
    </div>
  );
};
