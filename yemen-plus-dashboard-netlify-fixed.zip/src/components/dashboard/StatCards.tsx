import React from 'react';
import {
  Users,
  UserPlus,
  MessageSquare,
  ClipboardList,
  AlertCircle,
  Flame,
  Sun,
  UserCheck,
  ArrowUpRight
} from 'lucide-react';
import { DashboardStats, ActiveTab } from '../../types';

interface StatCardsProps {
  stats: DashboardStats;
  onNavigate: (tab: ActiveTab) => void;
}

export const StatCards: React.FC<StatCardsProps> = ({ stats, onNavigate }) => {
  const cards = [
    {
      title: 'إجمالي العملاء',
      value: stats.totalCustomers,
      icon: Users,
      meta: 'في قاعدة بيانات D1',
      color: 'from-blue-950/40 to-slate-900 border-blue-500/30 text-blue-400',
      iconBg: 'bg-blue-500/20 text-blue-400',
      action: () => onNavigate('customers'),
    },
    {
      title: 'العملاء الجدد اليوم',
      value: stats.newCustomersToday,
      icon: UserPlus,
      meta: 'اليوم',
      color: 'from-emerald-950/40 to-slate-900 border-emerald-500/30 text-emerald-400',
      iconBg: 'bg-emerald-500/20 text-emerald-400',
      action: () => onNavigate('customers'),
    },
    {
      title: 'المحادثات النشطة',
      value: stats.activeConversations,
      icon: MessageSquare,
      meta: 'مباشرة على واتساب',
      color: 'from-indigo-950/40 to-slate-900 border-indigo-500/30 text-indigo-400',
      iconBg: 'bg-indigo-500/20 text-indigo-400',
      action: () => onNavigate('conversations'),
    },
    {
      title: 'الطلبات الجديدة',
      value: stats.newRequests,
      icon: ClipboardList,
      meta: 'تحتاج استجابة',
      color: 'from-cyan-950/40 to-slate-900 border-cyan-500/30 text-cyan-400',
      iconBg: 'bg-cyan-500/20 text-cyan-400',
      action: () => onNavigate('requests'),
    },
    {
      title: 'طلبات قيد المتابعة',
      value: stats.followUpRequests,
      icon: AlertCircle,
      meta: 'قيد التنفيذ / مستمرة',
      color: 'from-amber-950/40 to-slate-900 border-amber-500/30 text-amber-400',
      iconBg: 'bg-amber-500/20 text-amber-400',
      action: () => onNavigate('requests'),
    },
    {
      title: 'العملاء الحارين (Hot)',
      value: stats.hotLeadsCount,
      icon: Flame,
      meta: 'فرص بيع فورية',
      color: 'from-rose-950/40 to-slate-900 border-rose-500/30 text-rose-400',
      iconBg: 'bg-rose-500/20 text-rose-400',
      action: () => onNavigate('leads'),
    },
    {
      title: 'العملاء المهتمين (Warm)',
      value: stats.warmLeadsCount,
      icon: Sun,
      meta: 'استفسارات عروض أسعار',
      color: 'from-orange-950/40 to-slate-900 border-orange-500/30 text-orange-400',
      iconBg: 'bg-orange-500/20 text-orange-400',
      action: () => onNavigate('leads'),
    },
    {
      title: 'طلبات التدخل البشري',
      value: stats.humanRequestsCount,
      icon: UserCheck,
      meta: 'بانتظار المشرف',
      color:
        stats.humanRequestsCount > 0
          ? 'from-red-950/60 to-slate-900 border-red-500/60 text-red-300 ring-1 ring-red-500/40'
          : 'from-slate-900 to-slate-950 border-slate-800 text-slate-400',
      iconBg: stats.humanRequestsCount > 0 ? 'bg-red-500 text-white' : 'bg-slate-800 text-slate-400',
      action: () => onNavigate('human-requests'),
      urgent: stats.humanRequestsCount > 0,
    },
  ];

  return (
    <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
      {cards.map((card, idx) => {
        const Icon = card.icon;
        return (
          <div
            key={idx}
            onClick={card.action}
            className={`p-4 sm:p-5 rounded-2xl bg-gradient-to-b border backdrop-blur-xl transition-all duration-200 cursor-pointer hover:-translate-y-0.5 hover:shadow-xl hover:shadow-black/50 ${
              card.color
            } ${card.urgent ? 'animate-pulse' : ''}`}
          >
            <div className="flex items-center justify-between gap-2">
              <span className="text-xs font-semibold text-slate-300 truncate">{card.title}</span>
              <div className={`p-2 rounded-xl shrink-0 ${card.iconBg}`}>
                <Icon className="w-4 h-4" />
              </div>
            </div>

            <div className="mt-3 flex items-baseline justify-between">
              <span className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
                {card.value}
              </span>
              <div className="flex items-center gap-1 text-[11px] text-slate-400">
                <span className="hidden sm:inline truncate">{card.meta}</span>
                <ArrowUpRight className="w-3 h-3 shrink-0 text-slate-400" />
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
};
