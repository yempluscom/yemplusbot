import React from 'react';
import { Customer, RequestItem, Conversation } from '../../types';
import { UserCheck, MessageSquare, Phone, CheckCircle2, Clock, ArrowLeft, ExternalLink, AlertTriangle } from 'lucide-react';
import { LeadBadge, PriorityBadge } from '../ui/Badge';

interface QuickHumanHandoffProps {
  humanRequests: any[];
  onOpenConversation: (conversationId: number) => void;
  onOpenCustomer: (customerId: number) => void;
  onResolve: (customerId: number) => void;
  onNavigateToHumanTab: () => void;
}

export const QuickHumanHandoff: React.FC<QuickHumanHandoffProps> = ({
  humanRequests,
  onOpenConversation,
  onOpenCustomer,
  onResolve,
  onNavigateToHumanTab,
}) => {
  if (!humanRequests || humanRequests.length === 0) {
    return (
      <div className="p-6 rounded-2xl bg-slate-900/90 border border-slate-800 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
            <CheckCircle2 className="w-5 h-5" />
          </div>
          <div>
            <h4 className="text-sm font-bold text-white">لا توجد طلبات تدخل بشري معلقة</h4>
            <p className="text-xs text-slate-400">المساعد الذكي (Gemini) يدير جميع محادثات العملاء بنجاح وبشكل طبيعي 🌷</p>
          </div>
        </div>
        <span className="text-xs px-3 py-1 rounded-full bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 font-medium">
          الوضع مستقر 100%
        </span>
      </div>
    );
  }

  return (
    <div className="p-6 rounded-2xl bg-gradient-to-br from-red-950/30 via-slate-900/90 to-slate-900/90 border border-red-500/40 shadow-xl shadow-red-950/20">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2.5">
          <div className="p-2 rounded-xl bg-red-600 text-white animate-bounce">
            <AlertTriangle className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <span>تنبيهات التدخل البشري العاجلة</span>
              <span className="text-xs font-extrabold px-2 py-0.5 rounded-full bg-red-600 text-white">
                {humanRequests.length} عملاء
              </span>
            </h3>
            <p className="text-xs text-red-300/80">عملاء طلبوا التحدث مع موظف أو إدارة يمن بلاس مباشرة</p>
          </div>
        </div>

        <button
          onClick={onNavigateToHumanTab}
          className="text-xs font-semibold text-red-400 hover:text-red-300 flex items-center gap-1 transition-colors"
        >
          <span>عرض جميع الطلبات</span>
          <ArrowLeft className="w-3.5 h-3.5" />
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {humanRequests.slice(0, 3).map((item) => {
          const cleanPhone = item.phone.replace(/\D/g, '');
          const waUrl = `https://wa.me/${cleanPhone}`;

          return (
            <div
              key={item.customer_id}
              className="p-4 rounded-xl bg-slate-900 border border-red-500/30 hover:border-red-500/60 transition-all flex flex-col justify-between"
            >
              <div>
                <div className="flex items-start justify-between gap-2 mb-2">
                  <div>
                    <h4 className="font-bold text-sm text-white">{item.name || 'عميل يمن بلاس'}</h4>
                    <span className="text-xs text-slate-400 font-mono">+{item.phone}</span>
                  </div>
                  <LeadBadge status={item.lead_status || 'hot'} size="sm" />
                </div>

                <div className="p-2.5 rounded-lg bg-slate-950/70 border border-slate-800 text-xs text-slate-300 mb-3 space-y-1">
                  <div className="font-semibold text-emerald-400 truncate">
                    {item.service || 'طلب استفسار عن خدمة'}
                  </div>
                  <div className="text-slate-400 text-[11px] line-clamp-2 italic">
                    "{item.last_message || 'طلب التحدث مع موظف'}"
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2 pt-2 border-t border-slate-800">
                <a
                  href={waUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="flex-1 flex items-center justify-center gap-1 py-1.5 px-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold transition-colors"
                  title="فتح واتساب مباشرة"
                >
                  <Phone className="w-3.5 h-3.5" />
                  <span>واتساب</span>
                </a>

                {item.conversation_id && (
                  <button
                    onClick={() => onOpenConversation(item.conversation_id)}
                    className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors"
                    title="عرض المحادثة بالداشبورد"
                  >
                    <MessageSquare className="w-4 h-4" />
                  </button>
                )}

                <button
                  onClick={() => onResolve(item.customer_id)}
                  className="p-1.5 rounded-lg bg-red-950/60 hover:bg-red-900/60 text-red-400 hover:text-red-300 border border-red-500/30 transition-colors"
                  title="تم الرد وحل الطلب"
                >
                  <CheckCircle2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
