import React, { useState } from 'react';
import { RequestItem, RequestStatus, RequestPriority } from '../../types';
import { api } from '../../lib/api';
import {
  ClipboardList,
  Search,
  Filter,
  Kanban,
  Table as TableIcon,
  Phone,
  MessageSquare,
  ChevronDown,
  Sparkles,
  CheckCircle2,
  Clock,
  Ban,
  AlertCircle,
  ArrowRight
} from 'lucide-react';
import { RequestStatusBadge, PriorityBadge, LeadBadge } from '../ui/Badge';

interface RequestsBoardProps {
  requests: RequestItem[];
  onRefresh: () => void;
  onOpenConversation: (conversationId: number) => void;
  onOpenCustomer: (customerId: number) => void;
}

export const RequestsBoard: React.FC<RequestsBoardProps> = ({
  requests,
  onRefresh,
  onOpenConversation,
  onOpenCustomer,
}) => {
  const [viewMode, setViewMode] = useState<'kanban' | 'table'>('kanban');
  const [searchTerm, setSearchTerm] = useState('');
  const [filterPriority, setFilterPriority] = useState<string>('all');
  const [filterService, setFilterService] = useState<string>('all');
  const [updatingId, setUpdatingId] = useState<number | null>(null);

  const services = Array.from(new Set(requests.map((r) => r.service).filter(Boolean))) as string[];

  const handleUpdateStatus = async (requestId: number, newStatus: RequestStatus) => {
    setUpdatingId(requestId);
    try {
      await api.updateRequest(requestId, { status: newStatus });
      onRefresh();
    } catch (err) {
      console.error('Error updating request status:', err);
    } finally {
      setUpdatingId(null);
    }
  };

  const handleUpdatePriority = async (requestId: number, newPriority: RequestPriority) => {
    setUpdatingId(requestId);
    try {
      await api.updateRequest(requestId, { priority: newPriority });
      onRefresh();
    } catch (err) {
      console.error('Error updating priority:', err);
    } finally {
      setUpdatingId(null);
    }
  };

  const filteredRequests = requests.filter((r) => {
    const matchesSearch =
      searchTerm === '' ||
      (r.customer_name && r.customer_name.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (r.service && r.service.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (r.customer_phone && r.customer_phone.includes(searchTerm));

    const matchesPriority = filterPriority === 'all' || r.priority === filterPriority;
    const matchesService = filterService === 'all' || r.service === filterService;

    return matchesSearch && matchesPriority && matchesService;
  });

  const columns: { id: RequestStatus; label: string; color: string }[] = [
    { id: 'new', label: 'طلبات جديدة', color: 'border-emerald-500/50 bg-emerald-950/20' },
    { id: 'in_progress', label: 'قيد التنفيذ والمتابعة', color: 'border-indigo-500/50 bg-indigo-950/20' },
    { id: 'completed', label: 'مكتملة ومعتمدة', color: 'border-teal-500/50 bg-teal-950/20' },
    { id: 'closed', label: 'مغلقة / غير جادة', color: 'border-slate-700/50 bg-slate-900/40' },
  ];

  return (
    <div className="space-y-5">
      {/* Filter Bar */}
      <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 flex flex-col md:flex-row items-center justify-between gap-3">
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute right-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="بحث في تفاصيل الطلبات والعملاء..."
            className="w-full pl-3 pr-10 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
          />
        </div>

        <div className="flex flex-wrap items-center gap-2.5 w-full md:w-auto">
          {/* Priority filter */}
          <select
            value={filterPriority}
            onChange={(e) => setFilterPriority(e.target.value)}
            className="py-2 px-3 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-300 focus:outline-none"
          >
            <option value="all">جميع الأولويات</option>
            <option value="high">🚨 أولوية عاجلة (High)</option>
            <option value="normal">عادية (Normal)</option>
          </select>

          {/* Service filter */}
          <select
            value={filterService}
            onChange={(e) => setFilterService(e.target.value)}
            className="py-2 px-3 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-300 focus:outline-none"
          >
            <option value="all">جميع الخدمات</option>
            {services.map((s, idx) => (
              <option key={idx} value={s}>{s}</option>
            ))}
          </select>

          {/* View toggle */}
          <div className="flex items-center p-1 bg-slate-950 rounded-xl border border-slate-800">
            <button
              onClick={() => setViewMode('kanban')}
              className={`p-1.5 rounded-lg text-xs font-semibold flex items-center gap-1 transition-colors ${
                viewMode === 'kanban' ? 'bg-slate-800 text-white' : 'text-slate-400 hover:text-white'
              }`}
              title="لوحة كانبان (Kanban)"
            >
              <Kanban className="w-3.5 h-3.5" />
              <span>كانبان</span>
            </button>
            <button
              onClick={() => setViewMode('table')}
              className={`p-1.5 rounded-lg text-xs font-semibold flex items-center gap-1 transition-colors ${
                viewMode === 'table' ? 'bg-slate-800 text-white' : 'text-slate-400 hover:text-white'
              }`}
              title="جدول تفصيلي"
            >
              <TableIcon className="w-3.5 h-3.5" />
              <span>جدول</span>
            </button>
          </div>
        </div>
      </div>

      {/* Kanban View */}
      {viewMode === 'kanban' ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {columns.map((col) => {
            const colRequests = filteredRequests.filter((r) => r.status === col.id);

            return (
              <div
                key={col.id}
                className={`p-4 rounded-2xl border ${col.color} flex flex-col h-[700px] shadow-lg`}
              >
                {/* Column Header */}
                <div className="flex items-center justify-between pb-3 border-b border-slate-800/80 mb-3">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-xs text-white">{col.label}</span>
                  </div>
                  <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-slate-900 text-slate-300 border border-slate-800">
                    {colRequests.length}
                  </span>
                </div>

                {/* Cards List */}
                <div className="flex-1 overflow-y-auto space-y-3 pr-1">
                  {colRequests.length > 0 ? (
                    colRequests.map((req) => {
                      const cleanPhone = req.customer_phone ? req.customer_phone.replace(/\D/g, '') : '';
                      const waUrl = cleanPhone ? `https://wa.me/${cleanPhone}` : '#';

                      return (
                        <div
                          key={req.id}
                          className="p-3.5 rounded-xl bg-slate-900/90 border border-slate-800 hover:border-slate-700 transition-all shadow-md space-y-2.5"
                        >
                          <div className="flex items-start justify-between gap-1">
                            <button
                              onClick={() => onOpenCustomer(req.customer_id)}
                              className="font-bold text-xs text-white hover:text-emerald-400 text-right truncate max-w-[140px]"
                            >
                              {req.customer_name || 'عميل'}
                            </button>
                            <PriorityBadge priority={req.priority} size="sm" />
                          </div>

                          <div className="text-xs font-semibold text-emerald-400">
                            {req.service || 'خدمة غير محددة'}
                          </div>

                          {/* Extracted project summary */}
                          {req.parsed_details && (
                            <div className="p-2 rounded-lg bg-slate-950 text-[11px] text-slate-300 space-y-1">
                              {req.parsed_details.business && (
                                <div className="truncate text-slate-400">
                                  <span className="font-semibold text-slate-300">النشاط:</span> {req.parsed_details.business}
                                </div>
                              )}
                              {req.parsed_details.budget && (
                                <div className="text-emerald-400 font-medium">
                                  <span>الميزانية:</span> {req.parsed_details.budget}
                                </div>
                              )}
                            </div>
                          )}

                          {/* Move Status Select */}
                          <div className="pt-2 border-t border-slate-800 flex items-center justify-between gap-1">
                            <select
                              value={req.status}
                              disabled={updatingId === req.id}
                              onChange={(e) => handleUpdateStatus(req.id, e.target.value as RequestStatus)}
                              className="py-1 px-1.5 rounded-lg bg-slate-950 border border-slate-800 text-[10px] text-slate-300 focus:outline-none"
                            >
                              <option value="new">جديد</option>
                              <option value="in_progress">قيد التنفيذ</option>
                              <option value="completed">مكتمل</option>
                              <option value="closed">مغلق</option>
                            </select>

                            <div className="flex items-center gap-1">
                              <a
                                href={waUrl}
                                target="_blank"
                                rel="noreferrer"
                                className="p-1 rounded bg-emerald-600/20 text-emerald-400 hover:bg-emerald-600 hover:text-white transition-colors"
                                title="واتساب"
                              >
                                <Phone className="w-3 h-3" />
                              </a>
                              {req.conversation_id && (
                                <button
                                  onClick={() => onOpenConversation(req.conversation_id)}
                                  className="p-1 rounded bg-slate-800 text-slate-300 hover:text-white transition-colors"
                                  title="فتح المحادثة"
                                >
                                  <MessageSquare className="w-3 h-3" />
                                </button>
                              )}
                            </div>
                          </div>
                        </div>
                      );
                    })
                  ) : (
                    <div className="h-full flex items-center justify-center text-center text-xs text-slate-600">
                      فارغ
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        /* Table View */
        <div className="rounded-2xl bg-slate-900/90 border border-slate-800 overflow-hidden shadow-xl">
          <div className="overflow-x-auto">
            <table className="w-full text-right border-collapse text-xs">
              <thead>
                <tr className="border-b border-slate-800 bg-slate-950/60 text-slate-400 font-semibold">
                  <th className="py-3 px-4">رقم الطلب والعميل</th>
                  <th className="py-3 px-4">الخدمة</th>
                  <th className="py-3 px-4">الميزانية والنشاط</th>
                  <th className="py-3 px-4 text-center">الأولوية</th>
                  <th className="py-3 px-4 text-center">الحالة</th>
                  <th className="py-3 px-4 text-center">تغيير الحالة</th>
                  <th className="py-3 px-4 text-center">الإجراءات</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {filteredRequests.map((req) => (
                  <tr key={req.id} className="hover:bg-slate-800/50 transition-colors">
                    <td className="py-3 px-4">
                      <div className="font-bold text-white">طلب #{req.id}</div>
                      <button
                        onClick={() => onOpenCustomer(req.customer_id)}
                        className="text-slate-400 hover:text-emerald-400 text-[11px] underline mt-0.5"
                      >
                        {req.customer_name || 'عميل'} (+{req.customer_phone})
                      </button>
                    </td>
                    <td className="py-3 px-4 font-semibold text-emerald-400">{req.service}</td>
                    <td className="py-3 px-4 text-slate-300">
                      <div>{req.parsed_details?.business || 'غير محدد'}</div>
                      <div className="text-emerald-400 text-[11px] font-bold">{req.parsed_details?.budget || ''}</div>
                    </td>
                    <td className="py-3 px-4 text-center">
                      <PriorityBadge priority={req.priority} size="sm" />
                    </td>
                    <td className="py-3 px-4 text-center">
                      <RequestStatusBadge status={req.status} size="sm" />
                    </td>
                    <td className="py-3 px-4 text-center">
                      <select
                        value={req.status}
                        onChange={(e) => handleUpdateStatus(req.id, e.target.value as RequestStatus)}
                        className="py-1 px-2 rounded-lg bg-slate-950 border border-slate-800 text-xs text-white"
                      >
                        <option value="new">طلب جديد</option>
                        <option value="in_progress">قيد التنفيذ</option>
                        <option value="completed">مكتمل</option>
                        <option value="closed">مغلق</option>
                      </select>
                    </td>
                    <td className="py-3 px-4 text-center">
                      <div className="flex items-center justify-center gap-2">
                        <a
                          href={`https://wa.me/${req.customer_phone?.replace(/\D/g, '')}`}
                          target="_blank"
                          rel="noreferrer"
                          className="p-1.5 rounded-lg bg-emerald-600/20 hover:bg-emerald-600 text-emerald-400 hover:text-white"
                        >
                          <Phone className="w-3.5 h-3.5" />
                        </a>
                        {req.conversation_id && (
                          <button
                            onClick={() => onOpenConversation(req.conversation_id)}
                            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300"
                          >
                            <MessageSquare className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
