import React, { useState, useEffect } from 'react';
import {
  LayoutDashboard,
  Users,
  MessageSquare,
  ClipboardList,
  Target,
  UserCheck,
  BarChart3,
  Settings,
  Sparkles,
  ChevronRight,
  ChevronLeft,
  X,
  ExternalLink,
  ShieldCheck,
  Bot
} from 'lucide-react';
import { ActiveTab, DashboardStats } from '../../types';

interface SidebarProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  stats?: DashboardStats | null;
  isWorkerLive?: boolean;
  isOpen: boolean;
  setIsOpen: (open: boolean) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  setActiveTab,
  stats,
  isWorkerLive = false,
  isOpen,
  setIsOpen,
}) => {
  const [isCollapsed, setIsCollapsed] = useState(() => {
    try {
      return localStorage.getItem('yemplus_sidebar_collapsed') === 'true';
    } catch {
      return false;
    }
  });

  const toggleCollapse = () => {
    const next = !isCollapsed;
    setIsCollapsed(next);
    try {
      localStorage.setItem('yemplus_sidebar_collapsed', String(next));
    } catch {}
  };

  const navItems = [
    {
      id: 'dashboard' as ActiveTab,
      label: 'الرئيسية',
      icon: LayoutDashboard,
      badge: null,
    },
    {
      id: 'customers' as ActiveTab,
      label: 'العملاء',
      icon: Users,
      badge: stats?.totalCustomers || null,
      badgeColor: 'bg-slate-800 text-slate-300 border border-slate-700/60',
    },
    {
      id: 'conversations' as ActiveTab,
      label: 'المحادثات',
      icon: MessageSquare,
      badge: stats?.activeConversations || null,
      badgeColor: 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30',
    },
    {
      id: 'requests' as ActiveTab,
      label: 'الطلبات',
      icon: ClipboardList,
      badge: stats?.newRequests || null,
      badgeColor: 'bg-blue-500/20 text-blue-300 border border-blue-500/30',
    },
    {
      id: 'human-requests' as ActiveTab,
      label: 'تدخل بشري',
      icon: UserCheck,
      badge: stats?.humanRequestsCount || null,
      badgeColor: 'bg-red-600 text-white animate-pulse shadow-sm shadow-red-900/50',
      highlight: true,
    },
    {
      id: 'leads' as ActiveTab,
      label: 'العملاء المحتملين',
      icon: Target,
      badge: (stats?.hotLeadsCount || 0) + (stats?.warmLeadsCount || 0) || null,
      badgeColor: 'bg-amber-500/20 text-amber-300 border border-amber-500/30',
    },
    {
      id: 'analytics' as ActiveTab,
      label: 'التحليلات',
      icon: BarChart3,
      badge: null,
    },
    {
      id: 'settings' as ActiveTab,
      label: 'الإعدادات والربط',
      icon: Settings,
      badge: null,
    },
  ];

  return (
    <>
      {/* Mobile Backdrop */}
      {isOpen && (
        <div
          className="fixed inset-0 z-40 bg-black/70 backdrop-blur-sm lg:hidden transition-opacity"
          onClick={() => setIsOpen(false)}
        />
      )}

      {/* Sidebar Container */}
      <aside
        className={`fixed top-0 bottom-0 right-0 z-50 bg-slate-900/95 border-l border-slate-800/90 backdrop-blur-2xl flex flex-col transition-all duration-300 ease-in-out ${
          isOpen ? 'translate-x-0' : 'translate-x-full lg:translate-x-0'
        } ${isCollapsed ? 'lg:w-20' : 'lg:w-72'} w-72`}
      >
        {/* Brand Header */}
        <div className="p-4 sm:p-5 border-b border-slate-800/80 flex items-center justify-between">
          <div className="flex items-center gap-3 overflow-hidden">
            <div className="relative shrink-0">
              <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-emerald-600 via-teal-500 to-cyan-400 p-0.5 shadow-lg shadow-emerald-500/20">
                <div className="w-full h-full bg-slate-950 rounded-[14px] flex items-center justify-center">
                  <Sparkles className="w-5 h-5 text-emerald-400" />
                </div>
              </div>
              <span className="absolute -bottom-0.5 -left-0.5 w-3 h-3 bg-emerald-500 border-2 border-slate-900 rounded-full" />
            </div>

            {(!isCollapsed || isOpen) && (
              <div className="min-w-0">
                <div className="flex items-center gap-1.5">
                  <span className="font-extrabold text-base text-white truncate">يمن بلاس</span>
                  <span className="text-[10px] px-1.5 py-0.2 rounded bg-emerald-500/20 text-emerald-300 font-bold border border-emerald-500/30 shrink-0">
                    AI CRM
                  </span>
                </div>
                <p className="text-[11px] text-slate-400 truncate">لوحة إدارة المبيعات الذكية</p>
              </div>
            )}
          </div>

          {/* Close button for Mobile Drawer */}
          <button
            onClick={() => setIsOpen(false)}
            className="p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 lg:hidden"
            title="إغلاق القائمة"
          >
            <X className="w-5 h-5" />
          </button>

          {/* Desktop Collapse Toggle */}
          <button
            onClick={toggleCollapse}
            className="hidden lg:flex p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            title={isCollapsed ? 'توسيع القائمة' : 'تصغير القائمة'}
          >
            {isCollapsed ? <ChevronLeft className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
          </button>
        </div>

        {/* Live Status Pill */}
        {(!isCollapsed || isOpen) && (
          <div className="px-4 pt-3.5 pb-1">
            <div
              onClick={() => {
                setActiveTab('settings');
                setIsOpen(false);
              }}
              className={`p-2 rounded-xl border flex items-center justify-between cursor-pointer transition-all ${
                isWorkerLive
                  ? 'bg-emerald-950/40 border-emerald-500/40 hover:bg-emerald-900/40 text-emerald-300'
                  : 'bg-slate-800/60 border-slate-700/60 hover:bg-slate-800 text-slate-300'
              }`}
            >
              <div className="flex items-center gap-2 text-xs font-medium truncate">
                <span className="relative flex h-2 w-2 shrink-0">
                  <span
                    className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 ${
                      isWorkerLive ? 'bg-emerald-400' : 'bg-amber-400'
                    }`}
                  />
                  <span
                    className={`relative inline-flex rounded-full h-2 w-2 ${
                      isWorkerLive ? 'bg-emerald-500' : 'bg-amber-500'
                    }`}
                  />
                </span>
                <span className="truncate">{isWorkerLive ? 'متصل بـ Cloudflare D1' : 'المزامنة التلقائية نشطة'}</span>
              </div>
              <span className="text-[10px] text-slate-400 underline shrink-0">فحص</span>
            </div>
          </div>
        )}

        {/* Navigation Links */}
        <nav className="flex-1 px-3 py-3 space-y-1.5 overflow-y-auto">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;

            return (
              <button
                key={item.id}
                onClick={() => {
                  setActiveTab(item.id);
                  setIsOpen(false);
                }}
                title={item.label}
                className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-sm font-medium transition-all group relative ${
                  isActive
                    ? 'bg-gradient-to-r from-emerald-600/20 to-teal-600/10 text-emerald-400 border border-emerald-500/30 shadow-md shadow-emerald-950/30'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                } ${isCollapsed && !isOpen ? 'justify-center' : ''}`}
              >
                <div className="flex items-center gap-3 min-w-0">
                  <Icon
                    className={`w-5 h-5 shrink-0 transition-colors ${
                      isActive ? 'text-emerald-400' : 'text-slate-400 group-hover:text-slate-200'
                    }`}
                  />
                  {(!isCollapsed || isOpen) && (
                    <span className={`truncate ${isActive ? 'font-bold text-white' : ''}`}>
                      {item.label}
                    </span>
                  )}
                </div>

                {/* Badge if present */}
                {item.badge !== null && item.badge !== undefined && (!isCollapsed || isOpen) && (
                  <span
                    className={`px-2 py-0.5 text-[11px] font-bold rounded-full shrink-0 ${
                      item.badgeColor || 'bg-slate-800 text-slate-300'
                    }`}
                  >
                    {item.badge}
                  </span>
                )}

                {/* Collapsed Active Dot */}
                {isCollapsed && !isOpen && isActive && (
                  <span className="absolute left-2 w-1.5 h-1.5 rounded-full bg-emerald-400" />
                )}
              </button>
            );
          })}
        </nav>

        {/* Footer Brand Info */}
        {(!isCollapsed || isOpen) && (
          <div className="p-4 border-t border-slate-800/80 text-[11px] text-slate-400 space-y-1">
            <div className="flex items-center justify-between">
              <span className="text-slate-300 font-semibold">المساعد الذكي:</span>
              <span className="text-emerald-400 font-mono">Gemini 3.7 Flash</span>
            </div>
            <div className="flex items-center justify-between">
              <span>الرابط المعتمد:</span>
              <a
                href="https://yemplus.com"
                target="_blank"
                rel="noreferrer"
                className="text-cyan-400 hover:underline flex items-center gap-0.5"
              >
                <span>yemplus.com</span>
                <ExternalLink className="w-2.5 h-2.5" />
              </a>
            </div>
          </div>
        )}
      </aside>
    </>
  );
};
