import React, { useState, useRef, useEffect } from 'react';
import {
  Menu,
  RotateCw,
  Sparkles,
  UserCheck,
  Phone,
  LogOut,
  User,
  Shield,
  Settings,
  ChevronDown
} from 'lucide-react';
import { ActiveTab, DashboardStats } from '../../types';
import { useAuth } from '../../lib/auth';

interface HeaderProps {
  activeTab: ActiveTab;
  onToggleSidebar: () => void;
  onRefresh: () => void;
  isLoading: boolean;
  stats?: DashboardStats | null;
  onOpenHumanQueue: () => void;
  onNavigateToSettings: () => void;
}

const tabTitles: Record<ActiveTab, { title: string; subtitle: string }> = {
  dashboard: { title: 'لوحة التحكم الرئيسية', subtitle: 'نظرة شاملة ومؤشرات أداء وكيل الذكاء الاصطناعي والمبيعات' },
  customers: { title: 'إدارة العملاء', subtitle: 'قائمة العملاء وبياناتهم المستخرجة بواسطة الذكاء الاصطناعي' },
  'customer-details': { title: 'تفاصيل العميل', subtitle: 'الملف الشامل، تفاصيل المشروع، وسجل المحادثات' },
  conversations: { title: 'المحادثات المباشرة', subtitle: 'مركز إدارة رسائل واتساب والردود الآلية والبشرية' },
  requests: { title: 'إدارة الطلبات', subtitle: 'متابعة طلبات الخدمات، حالة الإنجاز، والأولويات' },
  'human-requests': { title: 'طلبات التدخل البشري', subtitle: 'العملاء الذين طلبوا التحدث مع موظف أو إدارة يمن بلاس' },
  leads: { title: 'تأهيل وتصنيف العملاء (Leads)', subtitle: 'مصفوفة العملاء الحارين (Hot) والمهتمين وفرص البيع' },
  analytics: { title: 'التحليلات والتقارير', subtitle: 'إحصائيات نمو العملاء، أكثر الخدمات طلبًا، وأداء المساعد' },
  settings: { title: 'الإعدادات والربط التقني', subtitle: 'إعدادات Cloudflare Worker، مفاتيح API، وقواعد المعرفة' },
};

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  onToggleSidebar,
  onRefresh,
  isLoading,
  stats,
  onOpenHumanQueue,
  onNavigateToSettings,
}) => {
  const { user, logout } = useAuth();
  const [profileOpen, setProfileOpen] = useState(false);
  const profileMenuRef = useRef<HTMLDivElement>(null);

  const current = tabTitles[activeTab] || { title: 'يمن بلاس', subtitle: '' };

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (profileMenuRef.current && !profileMenuRef.current.contains(event.target as Node)) {
        setProfileOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <header className="sticky top-0 z-30 bg-slate-900/90 backdrop-blur-xl border-b border-slate-800/90 px-4 sm:px-6 lg:px-8 py-3 flex items-center justify-between transition-all">
      {/* Left Area: Hamburger (mobile) + Page Titles */}
      <div className="flex items-center gap-3 min-w-0">
        <button
          onClick={onToggleSidebar}
          className="p-2 rounded-xl bg-slate-800/90 hover:bg-slate-700 text-slate-300 lg:hidden focus:outline-none transition-colors"
          title="القائمة الجانبية"
        >
          <Menu className="w-5 h-5" />
        </button>

        <div className="min-w-0">
          <div className="flex items-center gap-2">
            <h1 className="text-base sm:text-lg lg:text-xl font-extrabold text-white truncate">
              {current.title}
            </h1>
            {activeTab === 'dashboard' && (
              <span className="hidden sm:inline-flex items-center gap-1 text-[11px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 shrink-0 font-medium">
                <Sparkles className="w-3 h-3" /> Gemini 3.7 Flash
              </span>
            )}
          </div>
          <p className="text-xs text-slate-400 hidden md:block truncate mt-0.5">
            {current.subtitle}
          </p>
        </div>
      </div>

      {/* Right Area: Actions + User Profile */}
      <div className="flex items-center gap-2 sm:gap-3 shrink-0">
        {/* Urgent Human Alert Button if count > 0 */}
        {(stats?.humanRequestsCount ?? 0) > 0 && (
          <button
            onClick={onOpenHumanQueue}
            className="flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-xl bg-red-600 hover:bg-red-500 text-white text-xs font-bold shadow-lg shadow-red-900/40 transition-all animate-pulse"
          >
            <UserCheck className="w-4 h-4 shrink-0" />
            <span className="hidden sm:inline">تدخل بشري</span>
            <span className="bg-white text-red-700 font-extrabold px-1.5 py-0.2 rounded-full text-[11px]">
              {stats?.humanRequestsCount}
            </span>
          </button>
        )}

        {/* Refresh Button */}
        <button
          onClick={onRefresh}
          disabled={isLoading}
          className="p-2 sm:px-3 sm:py-2 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700/80 transition-all flex items-center gap-1.5 disabled:opacity-50"
          title="تحديث البيانات فوراً"
        >
          <RotateCw className={`w-4 h-4 ${isLoading ? 'animate-spin text-emerald-400' : ''}`} />
          <span className="hidden xl:inline text-xs">تحديث</span>
        </button>

        {/* WhatsApp Direct Action */}
        <a
          href="https://wa.me/967738880088"
          target="_blank"
          rel="noreferrer"
          className="hidden md:flex items-center gap-1.5 px-3 py-2 rounded-xl bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-300 border border-emerald-500/30 text-xs font-medium transition-colors"
          title="مراسلة المشرف على واتساب"
        >
          <Phone className="w-3.5 h-3.5" />
          <span>واتساب المشرف</span>
        </a>

        {/* User Profile Dropdown */}
        <div className="relative" ref={profileMenuRef}>
          <button
            onClick={() => setProfileOpen(!profileOpen)}
            className="flex items-center gap-2 p-1 sm:p-1.5 sm:pr-2.5 rounded-xl bg-slate-800/80 hover:bg-slate-700/90 border border-slate-700/80 transition-all text-right focus:outline-none"
          >
            <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-emerald-600 to-teal-500 flex items-center justify-center text-white font-bold text-xs shadow-sm">
              <User className="w-4 h-4" />
            </div>
            <div className="hidden sm:block text-right">
              <span className="text-xs font-bold text-white block leading-tight">
                {user?.name || 'إدارة يمن بلاس'}
              </span>
              <span className="text-[10px] text-emerald-400 block font-medium">المشرف العام</span>
            </div>
            <ChevronDown className="w-3.5 h-3.5 text-slate-400 hidden sm:block" />
          </button>

          {/* Dropdown Menu */}
          {profileOpen && (
            <div className="absolute left-0 mt-2 w-56 rounded-2xl bg-slate-900 border border-slate-800 shadow-2xl shadow-black/80 py-2 z-50 animate-fadeIn text-right">
              <div className="px-4 py-2.5 border-b border-slate-800">
                <p className="text-xs font-bold text-white truncate">{user?.name || 'إدارة يمن بلاس'}</p>
                <p className="text-[11px] text-slate-400 truncate">{user?.email || 'admin@yemplus.com'}</p>
                <div className="mt-1.5 inline-flex items-center gap-1 px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 text-[10px] font-semibold border border-emerald-500/30">
                  <Shield className="w-3 h-3" /> حساب إداري مصادق
                </div>
              </div>

              <div className="py-1">
                <button
                  onClick={() => {
                    setProfileOpen(false);
                    onNavigateToSettings();
                  }}
                  className="w-full px-4 py-2 text-xs text-slate-300 hover:text-white hover:bg-slate-800/80 flex items-center gap-2.5 transition-colors text-right"
                >
                  <Settings className="w-4 h-4 text-slate-400" />
                  <span>إعدادات النظام والربط</span>
                </button>

                <a
                  href="https://wa.me/967738880088"
                  target="_blank"
                  rel="noreferrer"
                  className="w-full px-4 py-2 text-xs text-slate-300 hover:text-white hover:bg-slate-800/80 flex items-center gap-2.5 transition-colors text-right"
                >
                  <Phone className="w-4 h-4 text-emerald-400" />
                  <span>دعم يمن بلاس المباشر</span>
                </a>
              </div>

              <div className="border-t border-slate-800 pt-1">
                <button
                  onClick={async () => {
                    setProfileOpen(false);
                    await logout();
                  }}
                  className="w-full px-4 py-2.5 text-xs text-red-400 hover:text-red-300 hover:bg-red-950/40 flex items-center gap-2.5 transition-colors text-right font-semibold"
                >
                  <LogOut className="w-4 h-4 text-red-400" />
                  <span>تسجيل الخروج</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};
