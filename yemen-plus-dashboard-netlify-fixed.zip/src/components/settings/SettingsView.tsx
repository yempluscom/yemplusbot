import React, { useState, useEffect } from 'react';
import { api } from '../../lib/api';
import {
  Zap,
  ShieldCheck,
  Database,
  Copy,
  Check,
  RefreshCw,
  AlertCircle,
  Key,
  Globe,
  Sparkles,
  Server,
  Lock,
  Terminal,
  HelpCircle,
  ArrowRight,
  Sliders
} from 'lucide-react';

interface SettingsViewProps {
  onConnectionTested?: () => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({ onConnectionTested }) => {
  const [isTesting, setIsTesting] = useState(false);
  const [pingResult, setPingResult] = useState<{
    success: boolean;
    message: string;
    status?: number;
    data?: any;
    error?: string;
    details?: string;
    solution?: string;
    workerUrl?: string;
    keyLength?: number;
    keyConfigured?: boolean;
  } | null>(null);
  const [copiedSection, setCopiedSection] = useState<string | null>(null);
  
  // Worker Status State
  const [workerStatus, setWorkerStatus] = useState<{
    workerUrl: string;
    isKeyConfigured: boolean;
    keyLength: number;
    keyPreview: string;
    isProductionReady: boolean;
  } | null>(null);
  const [loadingStatus, setLoadingStatus] = useState(false);

  // Custom key testing in UI
  const [showAdvancedKeyTest, setShowAdvancedKeyTest] = useState(false);
  const [customKeyInput, setCustomKeyInput] = useState('');
  const [customUrlInput, setCustomUrlInput] = useState('');
  const [saveAsRuntime, setSaveAsRuntime] = useState(true);

  const fetchStatus = async () => {
    setLoadingStatus(true);
    try {
      const st = await api.getWorkerStatus();
      setWorkerStatus(st);
      if (!customUrlInput && st.workerUrl) {
        setCustomUrlInput(st.workerUrl);
      }
    } catch {
      // Ignore if session not ready
    } finally {
      setLoadingStatus(false);
    }
  };

  useEffect(() => {
    fetchStatus();
  }, []);

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedSection(id);
    setTimeout(() => setCopiedSection(null), 2500);
  };

  const handleTestConnection = async (overrideKey?: string) => {
    setIsTesting(true);
    setPingResult(null);
    try {
      const res = await api.testWorkerConnection({
        custom_key: overrideKey !== undefined ? overrideKey : (customKeyInput.trim() || undefined),
        custom_url: customUrlInput.trim() || undefined,
        save_runtime: saveAsRuntime
      });
      setPingResult(res);
      if (res.success) {
        fetchStatus();
        if (onConnectionTested) onConnectionTested();
      }
    } catch (err: any) {
      setPingResult({
        success: false,
        message: `فشل الاتصال: ${err?.message || 'خطأ غير معروف'}`,
        error: err?.message
      });
    } finally {
      setIsTesting(false);
    }
  };

  const d1SchemaSql = `-- ==========================================
-- جداول قاعدة بيانات Cloudflare D1 لمنصة يمن بلاس
-- ==========================================

-- 1. جدول العملاء المستخرجين
CREATE TABLE IF NOT EXISTS customers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  phone TEXT UNIQUE NOT NULL,
  name TEXT,
  service TEXT,
  business TEXT,
  project TEXT,
  goal TEXT,
  budget TEXT,
  timeline TEXT,
  lead_status TEXT DEFAULT 'general', -- 'hot', 'warm', 'cold', 'general'
  needs_human INTEGER DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- 2. جدول المحادثات
CREATE TABLE IF NOT EXISTS conversations (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  customer_id INTEGER NOT NULL,
  status TEXT DEFAULT 'bot', -- 'bot', 'human', 'closed'
  last_message TEXT,
  last_message_at DATETIME,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (customer_id) REFERENCES customers(id)
);

-- 3. جدول الرسائل وسجل المحادثة
CREATE TABLE IF NOT EXISTS messages (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  conversation_id INTEGER NOT NULL,
  sender TEXT NOT NULL, -- 'customer', 'assistant', 'agent'
  message TEXT NOT NULL,
  message_type TEXT DEFAULT 'text', -- 'text', 'audio', 'image'
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (conversation_id) REFERENCES conversations(id)
);

-- 4. جدول طلبات الخدمات
CREATE TABLE IF NOT EXISTS requests (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  customer_id INTEGER NOT NULL,
  conversation_id INTEGER,
  service TEXT NOT NULL,
  details TEXT, -- JSON structure with extracted info
  status TEXT DEFAULT 'new', -- 'new', 'in_progress', 'completed', 'closed'
  priority TEXT DEFAULT 'normal', -- 'high', 'normal'
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (customer_id) REFERENCES customers(id),
  FOREIGN KEY (conversation_id) REFERENCES conversations(id)
);`;

  return (
    <div className="space-y-8 max-w-5xl mx-auto">
      {/* 1. Worker Connection & Live Ping */}
      <div className="p-6 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-6 shadow-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0">
              <Zap className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-bold text-base text-white">ربط Cloudflare Worker وقاعدة بيانات D1</h3>
              <p className="text-xs text-slate-400">فحص الاتصال الآمن بين الخادم الوسيط و Cloudflare Worker</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs px-3 py-1.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-semibold flex items-center gap-1.5">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>خادم آمن (Server-Side Proxy)</span>
            </span>
          </div>
        </div>

        {/* Server Config Status Badges */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div className="p-3.5 rounded-xl bg-slate-950/80 border border-slate-800 space-y-1">
            <div className="text-[11px] text-slate-400 flex items-center gap-1.5">
              <Globe className="w-3.5 h-3.5 text-cyan-400" />
              <span>عنوان الـ Worker المعتمد:</span>
            </div>
            <div className="font-mono text-xs text-cyan-300 truncate" title={workerStatus?.workerUrl || 'جاري التحميل...'}>
              {workerStatus?.workerUrl || 'https://whatsapp-gemini-webhook...'}
            </div>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-950/80 border border-slate-800 space-y-1">
            <div className="text-[11px] text-slate-400 flex items-center gap-1.5">
              <Key className="w-3.5 h-3.5 text-emerald-400" />
              <span>مفتاح DASHBOARD_API_KEY:</span>
            </div>
            <div className="font-mono text-xs text-emerald-300">
              {workerStatus?.isKeyConfigured ? (
                <span className="flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 inline-block"></span>
                  <span>مهيأ على الخادم ({workerStatus.keyPreview})</span>
                </span>
              ) : (
                <span className="text-amber-400">غير مهيأ في البيئة</span>
              )}
            </div>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-950/80 border border-slate-800 space-y-1">
            <div className="text-[11px] text-slate-400 flex items-center gap-1.5">
              <Server className="w-3.5 h-3.5 text-indigo-400" />
              <span>حالة الجاهزية للنشر (Netlify):</span>
            </div>
            <div className="font-semibold text-xs text-indigo-300 flex items-center gap-1.5">
              <Check className="w-3.5 h-3.5 text-emerald-400" />
              <span>جاهز للنشر 100% (Zero Secrets)</span>
            </div>
          </div>
        </div>

        {/* Security explanation */}
        <div className="p-4 rounded-xl bg-slate-950/60 border border-slate-800/80 text-xs text-slate-300 space-y-2">
          <div className="flex items-center gap-2 text-emerald-400 font-bold">
            <Lock className="w-4 h-4" />
            <span>معمارية حماية الأسرار (Server-Side Proxy Architecture)</span>
          </div>
          <p className="text-slate-400 leading-relaxed">
            تعمل لوحة التحكم عبر خادم وسيط (أو Netlify Serverless Functions عند النشر) لتمرير مفتاح التوثيق <code className="text-emerald-300 font-mono">DASHBOARD_API_KEY</code> إلى الـ Worker. لا يظهر المفتاح في المتصفح، مما يضمن أمانًا كاملًا للبيانات والمحادثات.
          </p>
        </div>

        {/* Action buttons */}
        <div className="flex flex-wrap items-center gap-3">
          <button
            onClick={() => handleTestConnection()}
            disabled={isTesting}
            className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-all disabled:opacity-50 shadow-lg shadow-emerald-950/50"
          >
            <RefreshCw className={`w-4 h-4 ${isTesting ? 'animate-spin' : ''}`} />
            <span>اختبار الاتصال بالـ Worker (Ping Test)</span>
          </button>

          <button
            onClick={() => setShowAdvancedKeyTest(!showAdvancedKeyTest)}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-xs font-semibold border border-slate-700 transition-colors"
          >
            <Sliders className="w-4 h-4" />
            <span>{showAdvancedKeyTest ? 'إخفاء اختبار المفاتيح اليدوي' : 'اختبار مفتاح API محدد يدوياً'}</span>
          </button>
        </div>

        {/* Advanced Key Tester */}
        {showAdvancedKeyTest && (
          <div className="p-4.5 rounded-xl bg-slate-950 border border-slate-800 space-y-4 text-xs animate-in fade-in duration-200">
            <div className="flex items-center justify-between">
              <div className="font-bold text-white flex items-center gap-2">
                <Key className="w-4 h-4 text-amber-400" />
                <span>اختبار مفتاح API مباشر مع Cloudflare Worker</span>
              </div>
              <span className="text-[11px] text-slate-400">للتجربة والتحقق المباشر</span>
            </div>

            <p className="text-slate-400 leading-relaxed">
              إذا قمت بتعيين مفتاح سري خاص في Cloudflare Worker Secrets عبر <code className="text-cyan-300 font-mono">wrangler secret put DASHBOARD_API_KEY</code> وتريد اختباره وتفعيله في المعاينة الحالية:
            </p>

            <div className="space-y-3">
              <div>
                <label className="block text-[11px] text-slate-400 mb-1">مفتاح DASHBOARD_API_KEY المراد اختباره:</label>
                <input
                  type="text"
                  value={customKeyInput}
                  onChange={(e) => setCustomKeyInput(e.target.value)}
                  placeholder="أدخل المفتاح السري المعتمد في Cloudflare..."
                  className="w-full px-3.5 py-2 rounded-lg bg-slate-900 border border-slate-700 text-white font-mono text-xs focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div className="flex items-center justify-between">
                <label className="flex items-center gap-2 cursor-pointer text-slate-300">
                  <input
                    type="checkbox"
                    checked={saveAsRuntime}
                    onChange={(e) => setSaveAsRuntime(e.target.checked)}
                    className="rounded border-slate-700 bg-slate-900 text-emerald-500 focus:ring-0"
                  />
                  <span>تفعيل هذا المفتاح تلقائياً للجلسة الحالية عند نجاح الاختبار</span>
                </label>

                <button
                  onClick={() => handleTestConnection(customKeyInput.trim())}
                  disabled={isTesting || !customKeyInput.trim()}
                  className="flex items-center gap-1.5 px-4 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold transition-all disabled:opacity-50"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${isTesting ? 'animate-spin' : ''}`} />
                  <span>فحص المفتاح الآن</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Ping Result Box */}
        {pingResult && (
          <div
            className={`p-5 rounded-xl text-xs space-y-3 border ${
              pingResult.success
                ? 'bg-emerald-950/40 border-emerald-500/40 text-emerald-200'
                : 'bg-rose-950/40 border-rose-500/40 text-rose-200'
            }`}
          >
            <div className="font-bold flex items-center justify-between">
              <div className="flex items-center gap-2 text-sm">
                {pingResult.success ? <Check className="w-5 h-5 text-emerald-400" /> : <AlertCircle className="w-5 h-5 text-rose-400" />}
                <span>{pingResult.message}</span>
              </div>
              {pingResult.status && (
                <span className={`px-2.5 py-0.5 rounded-full font-mono text-[11px] font-bold ${
                  pingResult.success ? 'bg-emerald-500/20 text-emerald-300' : 'bg-rose-500/20 text-rose-300'
                }`}>
                  HTTP {pingResult.status}
                </span>
              )}
            </div>

            {/* If 401 Unauthorized: Display full diagnostic & solution */}
            {pingResult.status === 401 && (
              <div className="p-4 rounded-xl bg-slate-950/90 border border-amber-500/30 text-slate-200 space-y-3">
                <div className="font-bold text-amber-400 flex items-center gap-2">
                  <HelpCircle className="w-4 h-4" />
                  <span>تحليل الخطأ وكيفية معالجته في دقيقة واحدة:</span>
                </div>
                
                <p className="text-slate-300 leading-relaxed text-[11px]">
                  <strong>السبب:</strong> الـ Cloudflare Worker يعمل بشكل صحيح ومتصل بالإنترنت، لكنه يرفض الاتصال لأن قيمة المتغير <code className="text-emerald-300 font-mono">DASHBOARD_API_KEY</code> المعينة في إعدادات Cloudflare Worker تختلف عن المفتاح الممرر من لوحة التحكم.
                </p>

                <div className="space-y-2">
                  <div className="font-semibold text-emerald-400 text-[11px]">الحل الموصى به:</div>
                  <div className="p-3 rounded-lg bg-slate-900 border border-slate-800 space-y-2">
                    <p className="text-[11px] text-slate-300">1. نفذ الأمر التالي في مجلد الـ Worker لتعيين نفس المفتاح السري:</p>
                    <div className="flex items-center justify-between bg-slate-950 p-2.5 rounded font-mono text-[11px] text-cyan-300 border border-slate-800">
                      <span>npx wrangler secret put DASHBOARD_API_KEY</span>
                      <button
                        onClick={() => handleCopy('npx wrangler secret put DASHBOARD_API_KEY', 'copy-wrangler')}
                        className="text-slate-400 hover:text-white"
                        title="نسخ الأمر"
                      >
                        {copiedSection === 'copy-wrangler' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                      </button>
                    </div>

                    <p className="text-[11px] text-slate-300 mt-2">2. أو توجه إلى لوحة Cloudflare Dashboard &gt; Workers &amp; Pages &gt; whatsapp-gemini-webhook &gt; Settings &gt; Variables &amp; Secrets وقم بإضافة <code className="text-emerald-300 font-mono">DASHBOARD_API_KEY</code> بنفس القيمة.</p>
                  </div>
                </div>
              </div>
            )}

            {pingResult.error && (
              <p className="text-rose-300 font-mono text-[11px]">تفاصيل الخطأ: {pingResult.error}</p>
            )}

            {pingResult.data && (
              <div>
                <span className="text-[11px] text-slate-400 block mb-1">الاستجابة المستلمة من الـ Worker:</span>
                <pre className="p-2.5 rounded-lg bg-slate-950 text-[10px] text-slate-300 font-mono overflow-x-auto border border-slate-800">
                  {JSON.stringify(pingResult.data, null, 2)}
                </pre>
              </div>
            )}
          </div>
        )}
      </div>

      {/* 2. D1 Database Schema SQL */}
      <div className="p-6 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-4 shadow-xl">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-500/20 text-indigo-400 flex items-center justify-center">
              <Database className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-base text-white">هيكل قاعدة بيانات Cloudflare D1</h3>
              <p className="text-xs text-slate-400">مخطط الجداول الرسمية (customers, conversations, messages, requests)</p>
            </div>
          </div>

          <button
            onClick={() => handleCopy(d1SchemaSql, 'd1-sql')}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 transition-colors"
          >
            {copiedSection === 'd1-sql' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copiedSection === 'd1-sql' ? 'تم النسخ!' : 'نسخ كود SQL'}</span>
          </button>
        </div>

        <div className="relative rounded-xl bg-slate-950 p-4 border border-slate-800 font-mono text-[11px] text-slate-300 overflow-x-auto max-h-60">
          <pre>{d1SchemaSql}</pre>
        </div>

        <div className="p-3.5 rounded-xl bg-slate-950/70 border border-slate-800 text-xs text-slate-300 space-y-1">
          <span className="font-bold text-emerald-400">أمر تشغيل الـ SQL عبر سطر الأوامر (Wrangler):</span>
          <code className="block bg-slate-900 p-2 rounded text-cyan-300 font-mono text-[11px] dir-ltr text-right">
            wrangler d1 execute yemplus_db --file=schema.sql
          </code>
        </div>
      </div>

      {/* 3. Production Environment Checklist */}
      <div className="p-6 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-4 shadow-xl">
        <div className="flex items-center gap-3 pb-3 border-b border-slate-800">
          <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center">
            <Server className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-bold text-base text-white">قائمة المتغيرات السرية للنشر والإنتاج (Netlify &amp; Server)</h3>
            <p className="text-xs text-slate-400">يتم ضبط هذه المتغيرات في Netlify Environment Variables</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
          <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800">
            <div className="font-bold text-emerald-400 font-mono">WORKER_API_URL</div>
            <div className="text-slate-400 mt-1">رابط الـ Cloudflare Worker المنشور الذي يحتوي على مسارات الـ API وربط D1.</div>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800">
            <div className="font-bold text-emerald-400 font-mono">DASHBOARD_API_KEY</div>
            <div className="text-slate-400 mt-1">مفتاح التوثيق الآمن للوحة التحكم Dashboard REST API.</div>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800">
            <div className="font-bold text-emerald-400 font-mono">ADMIN_EMAIL / ADMIN_USERNAME</div>
            <div className="text-slate-400 mt-1">اسم مستخدم أو بريد المشرف المعتمد لتسجيل الدخول.</div>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800">
            <div className="font-bold text-emerald-400 font-mono">ADMIN_PASSWORD</div>
            <div className="text-slate-400 mt-1">كلمة مرور حساب المشرف للدخول إلى لوحة التحكم.</div>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800">
            <div className="font-bold text-emerald-400 font-mono">AUTH_SECRET</div>
            <div className="text-slate-400 mt-1">مفتاح سري لتوقيع رموز الجلسات (HMAC-SHA256).</div>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800">
            <div className="font-bold text-emerald-400 font-mono">GEMINI_API_KEY</div>
            <div className="text-slate-400 mt-1">مفتاح Google Gemini للردود الذكية وتأهيل العملاء.</div>
          </div>
        </div>
      </div>

      {/* 4. WhatsApp Outbound Message Dispatch Instructions */}
      <div className="p-6 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-4 shadow-xl">
        <div className="flex items-center gap-3 pb-3 border-b border-slate-800">
          <div className="w-10 h-10 rounded-xl bg-blue-500/20 text-blue-400 flex items-center justify-center">
            <Sparkles className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-bold text-base text-white">كيف يصل رد المشرف إلى واتساب العميل مباشرة؟</h3>
            <p className="text-xs text-slate-400">آلية إرسال الردود اليدوية من اللوحة إلى هاتف العميل عبر Meta Cloud API</p>
          </div>
        </div>

        <div className="space-y-3 text-xs text-slate-300 leading-relaxed">
          <div className="flex items-start gap-2.5 p-3 rounded-xl bg-slate-950 border border-slate-800">
            <span className="w-5 h-5 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold text-[11px] shrink-0 mt-0.5">1</span>
            <div>
              <strong className="text-white">إرسال الرد من المحادثات المباشرة:</strong> عند كتابة رد والضغط على إرسال، تقوم اللوحة بإرسال طلب <code className="text-emerald-300 font-mono">POST /api/conversations/:id/messages</code> للخادم الوسيط.
            </div>
          </div>

          <div className="flex items-start gap-2.5 p-3 rounded-xl bg-slate-950 border border-slate-800">
            <span className="w-5 h-5 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold text-[11px] shrink-0 mt-0.5">2</span>
            <div>
              <strong className="text-white">إرسال الرسالة إلى هاتف العميل فوراً:</strong> يقوم الخادم بتمرير الطلب مع مفتاح الأمان إلى الـ Worker، الذي يرسل الرسالة فوراً عبر Meta WhatsApp Cloud API إلى رقم العميل، ويحفظها في D1 كـ <code className="text-blue-300 font-mono">sender: 'agent'</code>.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
