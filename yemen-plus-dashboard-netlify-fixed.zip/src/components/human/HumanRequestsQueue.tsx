import React, { useState } from 'react';
import { Customer } from '../../types';
import { api } from '../../lib/api';
import {
  UserCheck,
  Phone,
  MessageSquare,
  CheckCircle2,
  AlertTriangle,
  ExternalLink,
  Sparkles,
  RefreshCw,
  Clock,
  Briefcase
} from 'lucide-react';
import { LeadBadge, PriorityBadge } from '../ui/Badge';

interface HumanRequestsQueueProps {
  humanRequests: any[];
  onRefresh: () => void;
  onOpenConversation: (conversationId: number) => void;
  onOpenCustomer: (customerId: number) => void;
}

export const HumanRequestsQueue: React.FC<HumanRequestsQueueProps> = ({
  humanRequests,
  onRefresh,
  onOpenConversation,
  onOpenCustomer,
}) => {
  const [resolvingId, setResolvingId] = useState<number | null>(null);

  const handleResolve = async (customerId: number) => {
    setResolvingId(customerId);
    try {
      await api.resolveHumanRequest(customerId);
      onRefresh();
    } catch (err) {
      console.error('Error resolving request:', err);
    } finally {
      setResolvingId(null);
    }
  };

  return (
    <div className="space-y-6">
      {/* Alert Header Banner */}
      <div className="p-6 rounded-2xl bg-gradient-to-r from-red-950/60 via-slate-900 to-slate-900 border border-red-500/40 shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="flex items-start gap-4">
          <div className="p-3 rounded-2xl bg-red-600 text-white shadow-lg shadow-red-950/50 animate-pulse">
            <UserCheck className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-white flex items-center gap-2">
              <span>طابور طلبات التدخل البشري</span>
              <span className="text-xs px-2.5 py-0.5 rounded-full bg-red-600 text-white font-extrabold">
                {humanRequests.length} عملاء بانتظارك
              </span>
            </h2>
            <p className="text-xs text-red-200/80 mt-1 max-w-xl leading-relaxed">
              هؤلاء العملاء طلبوا صراحةً التواصل مع المشرف، أو طلبوا التحدث مع الأستاذ عبدالملك، أو استفسروا عن عقود واتفاقيات تتطلب موافقة بشرية.
            </p>
          </div>
        </div>

        <button
          onClick={onRefresh}
          className="flex items-center gap-2 px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold transition-colors border border-slate-700"
        >
          <RefreshCw className="w-4 h-4" />
          <span>تحديث القائمة</span>
        </button>
      </div>

      {/* Requests Grid */}
      {humanRequests.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {humanRequests.map((item) => {
            const cleanPhone = item.phone ? item.phone.replace(/\D/g, '') : '';
            const waUrl = cleanPhone ? `https://wa.me/${cleanPhone}` : '#';

            return (
              <div
                key={item.customer_id}
                className="p-5 rounded-2xl bg-slate-900/90 border border-red-500/30 hover:border-red-500/60 transition-all shadow-lg flex flex-col justify-between space-y-4"
              >
                {/* Header */}
                <div className="flex items-start justify-between gap-2 pb-3 border-b border-slate-800">
                  <div>
                    <button
                      onClick={() => onOpenCustomer(item.customer_id)}
                      className="font-bold text-sm text-white hover:text-emerald-400 text-right transition-colors"
                    >
                      {item.name || 'عميل يمن بلاس'}
                    </button>
                    <div className="text-xs text-slate-400 font-mono mt-0.5">+{item.phone}</div>
                  </div>
                  <LeadBadge status={item.lead_status || 'hot'} size="sm" />
                </div>

                {/* Body details */}
                <div className="space-y-3 text-xs">
                  <div>
                    <span className="text-slate-400 block mb-1">الخدمة المطلوبة:</span>
                    <div className="p-2 rounded-xl bg-slate-950 border border-slate-800 text-emerald-300 font-semibold truncate">
                      {item.service || 'غير محددة'}
                    </div>
                  </div>

                  {item.business && (
                    <div>
                      <span className="text-slate-400 block mb-1">النشاط:</span>
                      <div className="text-slate-200 truncate">{item.business}</div>
                    </div>
                  )}

                  {item.last_message && (
                    <div className="p-3 rounded-xl bg-red-950/30 border border-red-500/20 text-red-200">
                      <span className="font-semibold text-[10px] text-red-400 block mb-0.5">آخر رسالة من العميل:</span>
                      <p className="italic leading-relaxed">"{item.last_message}"</p>
                    </div>
                  )}
                </div>

                {/* Action Buttons */}
                <div className="pt-3 border-t border-slate-800 flex items-center gap-2">
                  <a
                    href={waUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="flex-1 flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-colors shadow-md shadow-emerald-950/40"
                  >
                    <Phone className="w-3.5 h-3.5" />
                    <span>مراسلة عبر واتساب</span>
                  </a>

                  {item.conversation_id && (
                    <button
                      onClick={() => onOpenConversation(item.conversation_id)}
                      className="p-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors"
                      title="فتح المحادثة"
                    >
                      <MessageSquare className="w-4 h-4" />
                    </button>
                  )}

                  <button
                    onClick={() => handleResolve(item.customer_id)}
                    disabled={resolvingId === item.customer_id}
                    className="flex items-center gap-1 p-2.5 rounded-xl bg-red-600/20 hover:bg-red-600/30 text-red-300 border border-red-500/40 text-xs font-semibold transition-colors disabled:opacity-50"
                    title="تمت المتابعة وحل الطلب"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    <span>حل</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <div className="p-16 rounded-2xl bg-slate-900/90 border border-slate-800 text-center space-y-3">
          <div className="w-16 h-16 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto">
            <CheckCircle2 className="w-8 h-8" />
          </div>
          <h3 className="text-base font-bold text-white">لا توجد أي طلبات تدخل بشري معلقة حالياً</h3>
          <p className="text-xs text-slate-400 max-w-md mx-auto">
            الوكيل الذكي (AI Bot) يتولى الإجابة على كافة العملاء وتأهيلهم واستخراج متطلبات المشاريع بشكل سليم 🌷
          </p>
        </div>
      )}
    </div>
  );
};
