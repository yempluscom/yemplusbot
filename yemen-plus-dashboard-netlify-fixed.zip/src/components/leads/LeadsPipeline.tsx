import React, { useState } from 'react';
import { Customer, LeadStatus } from '../../types';
import {
  Flame,
  Sun,
  Snowflake,
  Compass,
  DollarSign,
  Phone,
  MessageSquare,
  Sparkles,
  Download,
  Search,
  ExternalLink,
  ChevronLeft
} from 'lucide-react';
import { LeadBadge, HumanBadge } from '../ui/Badge';

interface LeadsPipelineProps {
  customers: Customer[];
  onOpenCustomer: (customer: Customer) => void;
  onOpenChat: (customerId: number) => void;
}

export const LeadsPipeline: React.FC<LeadsPipelineProps> = ({
  customers,
  onOpenCustomer,
  onOpenChat,
}) => {
  const [activeTab, setActiveTab] = useState<LeadStatus>('hot');
  const [searchTerm, setSearchTerm] = useState('');

  const hotLeads = customers.filter((c) => c.lead_status === 'hot');
  const warmLeads = customers.filter((c) => c.lead_status === 'warm');
  const coldLeads = customers.filter((c) => c.lead_status === 'cold');
  const generalLeads = customers.filter((c) => c.lead_status === 'general');

  const getActiveList = () => {
    switch (activeTab) {
      case 'hot':
        return hotLeads;
      case 'warm':
        return warmLeads;
      case 'cold':
        return coldLeads;
      case 'general':
      default:
        return generalLeads;
    }
  };

  const filtered = getActiveList().filter((c) => {
    if (!searchTerm) return true;
    const q = searchTerm.toLowerCase();
    return (
      (c.name && c.name.toLowerCase().includes(q)) ||
      c.phone.includes(q) ||
      (c.service && c.service.toLowerCase().includes(q)) ||
      (c.business && c.business.toLowerCase().includes(q))
    );
  });

  const handleExportCSV = () => {
    const rows = [
      ['ID', 'Name', 'Phone', 'Service', 'Business', 'Budget', 'Timeline', 'Lead Status'],
      ...customers.map((c) => [
        c.id,
        c.name || '',
        c.phone,
        c.service || '',
        c.business || '',
        c.budget || '',
        c.timeline || '',
        c.lead_status || '',
      ]),
    ];

    const csvContent = 'data:text/csv;charset=utf-8,\uFEFF' + rows.map((e) => e.join(',')).join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `yemen_plus_leads_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      {/* Overview Stat Strip */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div
          onClick={() => setActiveTab('hot')}
          className={`p-4 rounded-2xl border cursor-pointer transition-all ${
            activeTab === 'hot'
              ? 'bg-rose-950/40 border-rose-500 ring-2 ring-rose-500/30'
              : 'bg-slate-900/90 border-slate-800 hover:border-slate-700'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-rose-300">عملاء حارين (Hot)</span>
            <Flame className="w-4 h-4 text-rose-500 animate-pulse" />
          </div>
          <div className="text-2xl font-extrabold text-white mt-2">{hotLeads.length}</div>
          <p className="text-[11px] text-slate-400 mt-1">مستعدون للشراء ولديهم ميزانية وموعد محدد</p>
        </div>

        <div
          onClick={() => setActiveTab('warm')}
          className={`p-4 rounded-2xl border cursor-pointer transition-all ${
            activeTab === 'warm'
              ? 'bg-amber-950/40 border-amber-500 ring-2 ring-amber-500/30'
              : 'bg-slate-900/90 border-slate-800 hover:border-slate-700'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-amber-300">عملاء مهتمين (Warm)</span>
            <Sun className="w-4 h-4 text-amber-500" />
          </div>
          <div className="text-2xl font-extrabold text-white mt-2">{warmLeads.length}</div>
          <p className="text-[11px] text-slate-400 mt-1">يستفسرون عن التفاصيل والأسعار</p>
        </div>

        <div
          onClick={() => setActiveTab('cold')}
          className={`p-4 rounded-2xl border cursor-pointer transition-all ${
            activeTab === 'cold'
              ? 'bg-slate-800 border-slate-500 ring-2 ring-slate-500/30'
              : 'bg-slate-900/90 border-slate-800 hover:border-slate-700'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-300">اهتمام منخفض (Cold)</span>
            <Snowflake className="w-4 h-4 text-slate-400" />
          </div>
          <div className="text-2xl font-extrabold text-white mt-2">{coldLeads.length}</div>
          <p className="text-[11px] text-slate-400 mt-1">استفسارات عامة أو توقفت المتابعة</p>
        </div>

        <div
          onClick={() => setActiveTab('general')}
          className={`p-4 rounded-2xl border cursor-pointer transition-all ${
            activeTab === 'general'
              ? 'bg-blue-950/40 border-blue-500 ring-2 ring-blue-500/30'
              : 'bg-slate-900/90 border-slate-800 hover:border-slate-700'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-blue-300">عام (General)</span>
            <Compass className="w-4 h-4 text-blue-400" />
          </div>
          <div className="text-2xl font-extrabold text-white mt-2">{generalLeads.length}</div>
          <p className="text-[11px] text-slate-400 mt-1">محادثات جديدة قيد التأهيل والاستكشاف</p>
        </div>
      </div>

      {/* Action Header & Search */}
      <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 flex flex-col md:flex-row items-center justify-between gap-3">
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute right-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="بحث في قائمة العملاء المحتملين..."
            className="w-full pl-3 pr-10 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
          />
        </div>

        <button
          onClick={handleExportCSV}
          className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 transition-colors"
        >
          <Download className="w-4 h-4 text-emerald-400" />
          <span>تصدير العملاء (CSV / Excel)</span>
        </button>
      </div>

      {/* Leads Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filtered.length > 0 ? (
          filtered.map((customer) => {
            const cleanPhone = customer.phone.replace(/\D/g, '');
            const waUrl = `https://wa.me/${cleanPhone}`;

            return (
              <div
                key={customer.id}
                onClick={() => onOpenCustomer(customer)}
                className="p-5 rounded-2xl bg-slate-900/90 border border-slate-800 hover:border-slate-700 cursor-pointer transition-all shadow-md flex flex-col justify-between space-y-4 group"
              >
                <div>
                  <div className="flex items-start justify-between gap-2 pb-3 border-b border-slate-800">
                    <div>
                      <h4 className="font-bold text-sm text-white group-hover:text-emerald-400 transition-colors">
                        {customer.name || 'عميل غير مسمى'}
                      </h4>
                      <div className="text-xs text-slate-400 font-mono mt-0.5">+{customer.phone}</div>
                    </div>
                    <LeadBadge status={customer.lead_status || 'general'} size="sm" />
                  </div>

                  <div className="space-y-2.5 mt-3 text-xs">
                    <div>
                      <span className="text-slate-400 block mb-0.5">الخدمة:</span>
                      <span className="font-semibold text-emerald-400">{customer.service || 'غير محددة'}</span>
                    </div>

                    {customer.business && (
                      <div>
                        <span className="text-slate-400 block mb-0.5">النشاط التجاري:</span>
                        <span className="text-slate-200">{customer.business}</span>
                      </div>
                    )}

                    <div className="grid grid-cols-2 gap-2 pt-1">
                      <div className="p-2 rounded-lg bg-slate-950 border border-slate-800">
                        <span className="text-[10px] text-slate-400 block">الميزانية</span>
                        <span className="text-emerald-400 font-bold">{customer.budget || 'غير محدد'}</span>
                      </div>
                      <div className="p-2 rounded-lg bg-slate-950 border border-slate-800">
                        <span className="text-[10px] text-slate-400 block">الموعد</span>
                        <span className="text-slate-300 font-medium">{customer.timeline || 'غير محدد'}</span>
                      </div>
                    </div>
                  </div>
                </div>

                <div
                  className="pt-3 border-t border-slate-800 flex items-center justify-between"
                  onClick={(e) => e.stopPropagation()}
                >
                  <a
                    href={waUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-emerald-600/20 hover:bg-emerald-600 text-emerald-300 hover:text-white text-xs font-semibold transition-colors"
                  >
                    <Phone className="w-3.5 h-3.5" />
                    <span>مراسلة فورية</span>
                  </a>

                  <button
                    onClick={() => onOpenCustomer(customer)}
                    className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white"
                  >
                    <ChevronLeft className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })
        ) : (
          <div className="col-span-full p-12 text-center text-slate-500 text-xs">
            لا يوجد عملاء في هذه الفئة حالياً
          </div>
        )}
      </div>
    </div>
  );
};
