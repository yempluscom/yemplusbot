import React, { useState } from 'react';
import { useAuth } from '../../lib/auth';
import { Sparkles, Lock, Mail, Eye, EyeOff, ShieldCheck, ArrowLeft, AlertCircle } from 'lucide-react';
import { Button } from '../ui/Button';
import { Input } from '../ui/Input';

export const LoginPage: React.FC = () => {
  const { login } = useAuth();
  const [identifier, setIdentifier] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    const cleanId = identifier.trim();
    const cleanPass = password.trim();

    if (!cleanId || !cleanPass) {
      setErrorMessage('يرجى إدخال البريد الإلكتروني أو اسم المستخدم وكلمة المرور');
      return;
    }

    setIsLoading(true);
    try {
      await login(cleanId, cleanPass);
    } catch (err: any) {
      setErrorMessage(err?.message || 'بيانات الدخول غير صحيحة');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen min-h-[100dvh] w-full bg-slate-950 text-slate-100 flex flex-col justify-between items-center p-4 sm:p-6 lg:p-8 font-sans selection:bg-emerald-500 selection:text-white relative overflow-hidden">
      {/* Subtle Background Glows */}
      <div className="absolute top-1/4 -right-24 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-1/4 -left-24 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* Top Brand Header */}
      <div className="w-full max-w-md pt-4 flex items-center justify-between z-10">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-emerald-600 to-teal-500 p-0.5 shadow-md shadow-emerald-900/30">
            <div className="w-full h-full bg-slate-950 rounded-[10px] flex items-center justify-center">
              <Sparkles className="w-4 h-4 text-emerald-400" />
            </div>
          </div>
          <div>
            <span className="font-bold text-white text-base">يمن بلاس</span>
            <span className="text-[10px] text-emerald-400 block font-medium">AI Business Platform</span>
          </div>
        </div>
        <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-slate-900/80 border border-slate-800 text-[11px] text-slate-400">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
          <span>بوابة آمنة</span>
        </div>
      </div>

      {/* Main Login Card */}
      <div className="w-full max-w-md my-auto py-6 z-10">
        <div className="rounded-3xl bg-slate-900/90 border border-slate-800/90 backdrop-blur-2xl p-6 sm:p-8 shadow-2xl shadow-black/80">
          <div className="text-center mb-7">
            <div className="w-14 h-14 mx-auto mb-4 rounded-2xl bg-gradient-to-tr from-emerald-600/30 via-teal-500/20 to-cyan-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400 shadow-lg shadow-emerald-950/50">
              <Lock className="w-6 h-6" />
            </div>
            <h1 className="text-xl sm:text-2xl font-extrabold text-white tracking-tight">
              تسجيل الدخول إلى لوحة التحكم
            </h1>
            <p className="text-xs sm:text-sm text-slate-400 mt-1.5">
              منصة يمن بلاس لإدارة المحادثات الذكية والمبيعات
            </p>
          </div>

          {errorMessage && (
            <div className="mb-5 p-3.5 rounded-xl bg-red-950/40 border border-red-500/40 text-red-300 text-xs font-medium flex items-center gap-2.5">
              <AlertCircle className="w-4 h-4 shrink-0 text-red-400" />
              <span>{errorMessage}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <Input
                label="البريد الإلكتروني أو اسم المستخدم"
                type="text"
                value={identifier}
                onChange={(e) => setIdentifier(e.target.value)}
                placeholder="admin@yemplus.com أو admin"
                rightIcon={<Mail className="w-4 h-4" />}
                required
                autoFocus
                autoComplete="username"
              />
            </div>

            <div>
              <div className="relative">
                <Input
                  label="كلمة المرور"
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  rightIcon={<Lock className="w-4 h-4" />}
                  leftIcon={
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="p-1 text-slate-400 hover:text-slate-200 transition-colors focus:outline-none"
                      title={showPassword ? 'إخفاء كلمة المرور' : 'إظهار كلمة المرور'}
                    >
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  }
                  required
                  autoComplete="current-password"
                />
              </div>
            </div>

            <div className="pt-2">
              <Button
                type="submit"
                variant="primary"
                size="lg"
                className="w-full font-bold shadow-lg shadow-emerald-950/60"
                isLoading={isLoading}
                rightIcon={<ArrowLeft className="w-4 h-4" />}
              >
                دخول إلى لوحة التحكم
              </Button>
            </div>
          </form>

          <div className="mt-6 pt-5 border-t border-slate-800/80 text-center">
            <p className="text-[11px] text-slate-500">
              الدخول مقصور على المشرفين المعتمدين لمنصة يمن بلاس
            </p>
          </div>
        </div>
      </div>

      {/* Bottom Footer */}
      <div className="w-full max-w-md pb-4 text-center text-xs text-slate-400 z-10 flex items-center justify-between">
        <span>© {new Date().getFullYear()} يمن بلاس (Yemen Plus)</span>
        <span>مبيعات وخدمة عملاء ذكية</span>
      </div>
    </div>
  );
};
