import React, { useState, useEffect, useRef } from 'react';
import { Conversation, Message } from '../../types';
import { api } from '../../lib/api';
import {
  Search,
  MessageSquare,
  Phone,
  Send,
  UserCheck,
  Bot,
  User,
  Sparkles,
  RefreshCw,
  AlertCircle,
  Zap,
  ArrowRight,
  CheckCircle2,
  Volume2
} from 'lucide-react';
import { LeadBadge, HumanBadge, ConversationBadge } from '../ui/Badge';
import { Button } from '../ui/Button';
import { EmptyState } from '../ui/EmptyState';

interface ConversationHubProps {
  conversations: Conversation[];
  initialConversationId?: number | null;
  onRefresh: () => void;
}

export const ConversationHub: React.FC<ConversationHubProps> = ({
  conversations,
  initialConversationId,
  onRefresh,
}) => {
  const [selectedConvId, setSelectedConvId] = useState<number | null>(
    initialConversationId || (conversations.length > 0 ? conversations[0].id : null)
  );
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputText, setInputText] = useState('');
  const [isSending, setIsSending] = useState(false);
  const [isGeneratingAi, setIsGeneratingAi] = useState(false);
  const [filterStatus, setFilterStatus] = useState<'all' | 'bot' | 'human' | 'closed'>('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [isLoadingMessages, setIsLoadingMessages] = useState(false);
  const [whatsappNotice, setWhatsappNotice] = useState<{ type: 'success' | 'error' | 'info'; text: string } | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const isAutoScrollActive = useRef(true);

  useEffect(() => {
    if (initialConversationId) {
      setSelectedConvId(initialConversationId);
    } else if (!selectedConvId && conversations.length > 0) {
      // Default to first conversation on desktop
      if (window.innerWidth >= 1024) {
        setSelectedConvId(conversations[0].id);
      }
    }
  }, [initialConversationId, conversations]);

  // Real-time live polling for messages when a conversation is open
  useEffect(() => {
    if (!selectedConvId) return;

    loadMessages(selectedConvId, true);

    const interval = setInterval(() => {
      loadMessages(selectedConvId, false);
    }, 3000);

    return () => clearInterval(interval);
  }, [selectedConvId]);

  useEffect(() => {
    if (isAutoScrollActive.current) {
      scrollToBottom();
    }
  }, [messages]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const loadMessages = async (convId: number, isInitial = false) => {
    if (isInitial) setIsLoadingMessages(true);
    try {
      const msgs = await api.getMessages(convId);
      if (Array.isArray(msgs)) {
        const cleanMsgs: Message[] = msgs.map((m: any, i: number) => ({
          id: m.id || i + 1,
          conversation_id: m.conversation_id || convId,
          sender: m.sender || 'assistant',
          message: m.message || m.text || m.content || m.body || '',
          message_type: m.message_type || 'text',
          audio_url: m.audio_url || m.media_url || null,
          created_at: m.created_at || new Date().toISOString(),
        }));

        setMessages((prev) => {
          if (prev.length !== cleanMsgs.length) {
            return cleanMsgs;
          }
          if (prev.length > 0 && cleanMsgs.length > 0) {
            const prevLast = prev[prev.length - 1];
            const newLast = cleanMsgs[cleanMsgs.length - 1];
            if (prevLast.id !== newLast.id || prevLast.message !== newLast.message) {
              return cleanMsgs;
            }
          }
          return prev;
        });
      }
    } catch (err) {
      // Background polling fail-safe
    } finally {
      if (isInitial) setIsLoadingMessages(false);
    }
  };

  const formatMessageTime = (dateStr?: string) => {
    if (!dateStr) return new Date().toLocaleTimeString('ar-YE', { hour: '2-digit', minute: '2-digit' });
    const parsed = new Date(dateStr);
    if (isNaN(parsed.getTime())) {
      const fallback = new Date(typeof dateStr === 'number' ? dateStr : dateStr.replace(' ', 'T'));
      if (!isNaN(fallback.getTime())) {
        return fallback.toLocaleTimeString('ar-YE', { hour: '2-digit', minute: '2-digit' });
      }
      return new Date().toLocaleTimeString('ar-YE', { hour: '2-digit', minute: '2-digit' });
    }
    return parsed.toLocaleTimeString('ar-YE', { hour: '2-digit', minute: '2-digit' });
  };

  const selectedConv = conversations.find((c) => c.id === selectedConvId);

  const handleTriggerAiReply = async () => {
    if (!selectedConvId || isGeneratingAi) return;
    setIsGeneratingAi(true);
    try {
      const res = await api.triggerAiReply(selectedConvId);
      if (res && res.reply) {
        setWhatsappNotice({
          type: res.sent_to_whatsapp ? 'success' : res.whatsapp_error ? 'error' : 'success',
          text: res.sent_to_whatsapp
            ? `🤖 قام Gemini بالرد وإرسال الرسالة للعميل عبر الواتساب: "${res.reply.slice(0, 40)}..."`
            : res.whatsapp_error
            ? `تم توليد الرد لكن لم يصل لواتساب: ${res.whatsapp_error}`
            : `🤖 تم توليد رد البوت: "${res.reply.slice(0, 40)}..."`,
        });
        setTimeout(() => setWhatsappNotice(null), 6000);
        await loadMessages(selectedConvId, false);
      }
      onRefresh();
    } catch (err: any) {
      setWhatsappNotice({
        type: 'error',
        text: `فشل استدعاء البوت: ${err?.message || 'حدث خطأ غير متوقع'}`,
      });
    } finally {
      setIsGeneratingAi(false);
    }
  };

  const handleSendMessage = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!inputText.trim() || !selectedConvId || isSending) return;

    const text = inputText.trim();
    const tempMessage: Message = {
      id: Date.now(),
      conversation_id: selectedConvId,
      sender: 'agent',
      message: text,
      message_type: 'text',
      created_at: new Date().toISOString(),
    };

    setMessages((prev) => [...prev, tempMessage]);
    setInputText('');
    setIsSending(true);

    try {
      const res = await api.sendMessage(selectedConvId, text);
      if (res && res.message) {
        const formattedMsg: Message =
          typeof res.message === 'string'
            ? { ...tempMessage, message: res.message }
            : {
                id: res.message.id || tempMessage.id,
                conversation_id: res.message.conversation_id || selectedConvId,
                sender: 'agent',
                message: res.message.message || (res.message as any).text || (res.message as any).content || text,
                message_type: res.message.message_type || 'text',
                created_at: res.message.created_at || tempMessage.created_at,
              };

        setMessages((prev) => prev.map((m) => (m.id === tempMessage.id ? formattedMsg : m)));

        if (res.sent_to_whatsapp) {
          setWhatsappNotice({
            type: 'success',
            text: 'تم إرسال الرسالة إلى هاتف العميل عبر WhatsApp Cloud API بنجاح ✓',
          });
          setTimeout(() => setWhatsappNotice(null), 5000);
        } else if (res.whatsapp_error) {
          setWhatsappNotice({
            type: 'error',
            text: `تم حفظ الرد باللوحة لكن لم يصل للواتساب: ${res.whatsapp_error}`,
          });
        }
      }
      onRefresh();
    } catch (err: any) {
      setWhatsappNotice({
        type: 'error',
        text: `حدث خطأ أثناء الإرسال: ${err?.message || 'تعذر الوصول للخادم'}`,
      });
    } finally {
      setIsSending(false);
    }
  };

  const handleToggleStatus = async (newStatus: 'bot' | 'human' | 'closed') => {
    if (!selectedConvId) return;
    try {
      await api.updateConversationStatus(selectedConvId, newStatus);
      if (newStatus === 'bot') {
        setWhatsappNotice({
          type: 'success',
          text: '🤖 تم تفعيل رد الذكاء الاصطناعي (Gemini) تلقائياً على رسائل العميل القادمة.',
        });
      } else if (newStatus === 'human') {
        setWhatsappNotice({
          type: 'info',
          text: '👤 تم تفعيل وضع التدخل البشري — تم إيقاف الرد التلقائي للبوت لهذه المحادثة.',
        });
      }
      setTimeout(() => setWhatsappNotice(null), 6000);
      onRefresh();
    } catch (err) {
      console.error('Error updating status:', err);
    }
  };

  const handleCannedReply = (text: string) => {
    setInputText(text);
  };

  const filteredConversations = conversations.filter((conv) => {
    if (filterStatus === 'bot' && conv.status !== 'bot') return false;
    if (filterStatus === 'human' && conv.status !== 'human' && conv.needs_human !== 1 && conv.needs_human !== true)
      return false;
    if (filterStatus === 'closed' && conv.status !== 'closed') return false;

    if (searchTerm) {
      const term = searchTerm.toLowerCase();
      return (
        conv.customer_name?.toLowerCase().includes(term) ||
        conv.customer_phone?.includes(term) ||
        conv.last_message?.toLowerCase().includes(term) ||
        conv.customer_service?.toLowerCase().includes(term)
      );
    }

    return true;
  });

  const waUrl = selectedConv?.customer_phone
    ? `https://wa.me/${selectedConv.customer_phone.replace(/\+/g, '').trim()}`
    : '#';

  return (
    <div className="h-[calc(100dvh-130px)] min-h-[550px] flex rounded-2xl bg-slate-900/90 border border-slate-800/90 overflow-hidden shadow-2xl backdrop-blur-xl">
      {/* 1. Conversations List (Left Sidebar on Desktop, Hidden when chat is open on Mobile) */}
      <div
        className={`w-full lg:w-80 xl:w-96 border-l border-slate-800/90 flex flex-col bg-slate-950/60 ${
          selectedConvId ? 'hidden lg:flex' : 'flex'
        }`}
      >
        {/* Search & Filter Header */}
        <div className="p-3.5 border-b border-slate-800 space-y-2.5">
          <div className="relative">
            <Search className="w-4 h-4 absolute right-3 top-2.5 text-slate-400 pointer-events-none" />
            <input
              type="text"
              placeholder="بحث بالاسم، الرقم، أو الخدمة..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full py-2 pr-9 pl-3 text-xs rounded-xl bg-slate-900 border border-slate-800 text-slate-100 placeholder-slate-500 focus:outline-none focus:border-emerald-500"
            />
          </div>

          <div className="grid grid-cols-4 gap-1 p-1 bg-slate-900/80 rounded-xl border border-slate-800/80 text-[11px] text-slate-400">
            <button
              onClick={() => setFilterStatus('all')}
              className={`py-1 rounded-lg transition-colors text-center ${
                filterStatus === 'all' ? 'bg-slate-800 text-white font-bold' : 'hover:text-slate-200'
              }`}
            >
              الكل ({conversations.length})
            </button>
            <button
              onClick={() => setFilterStatus('human')}
              className={`py-1 rounded-lg transition-colors text-center ${
                filterStatus === 'human' ? 'bg-red-600 text-white font-bold' : 'hover:text-red-400'
              }`}
            >
              بشري
            </button>
            <button
              onClick={() => setFilterStatus('bot')}
              className={`py-1 rounded-lg transition-colors text-center ${
                filterStatus === 'bot' ? 'bg-emerald-600 text-white font-bold' : 'hover:text-emerald-400'
              }`}
            >
              Bot AI
            </button>
            <button
              onClick={() => setFilterStatus('closed')}
              className={`py-1 rounded-lg transition-colors text-center ${
                filterStatus === 'closed' ? 'bg-slate-800 text-slate-300 font-bold' : 'hover:text-slate-200'
              }`}
            >
              منتهية
            </button>
          </div>
        </div>

        {/* List of Conversations */}
        <div className="flex-1 overflow-y-auto divide-y divide-slate-800/50">
          {filteredConversations.length > 0 ? (
            filteredConversations.map((conv, index) => {
              const isSelected = conv.id === selectedConvId;
              const isHuman = conv.status === 'human' || conv.needs_human === 1 || conv.needs_human === true;
              const key = conv.id ? `conv-${conv.id}` : `conv-idx-${index}`;

              return (
                <div
                  key={key}
                  onClick={() => setSelectedConvId(conv.id)}
                  className={`p-3.5 cursor-pointer transition-all ${
                    isSelected
                      ? 'bg-slate-800/90 border-r-4 border-emerald-500'
                      : 'hover:bg-slate-900/60'
                  } ${isHuman && !isSelected ? 'bg-red-950/20' : ''}`}
                >
                  <div className="flex items-start justify-between gap-2 mb-1.5">
                    <div className="flex items-center gap-2.5 min-w-0">
                      <div className="w-8 h-8 rounded-xl bg-slate-800 text-emerald-400 font-bold text-xs flex items-center justify-center border border-slate-700 shrink-0">
                        {conv.customer_name ? conv.customer_name.slice(0, 2) : 'عم'}
                      </div>
                      <div className="min-w-0">
                        <div className="font-bold text-xs text-white truncate max-w-[130px] sm:max-w-[160px]">
                          {conv.customer_name || 'عميل واتساب'}
                        </div>
                        <span className="text-[10px] text-slate-400 font-mono block">+{conv.customer_phone}</span>
                      </div>
                    </div>

                    <div className="flex flex-col items-end gap-1 shrink-0">
                      <ConversationBadge status={conv.status} size="sm" />
                      {conv.lead_status && <LeadBadge status={conv.lead_status} size="sm" />}
                    </div>
                  </div>

                  <p className="text-[11px] text-slate-300 line-clamp-1 italic">
                    {conv.last_message || 'لا توجد رسائل'}
                  </p>

                  <div className="flex items-center justify-between text-[10px] text-slate-400 mt-2 pt-1 border-t border-slate-800/40">
                    <span className="truncate max-w-[140px] text-emerald-400 font-medium">
                      {conv.customer_service || 'خدمات يمن بلاس'}
                    </span>
                    <span>
                      {conv.last_message_at
                        ? new Date(conv.last_message_at).toLocaleTimeString('ar-YE', { hour: '2-digit', minute: '2-digit' })
                        : ''}
                    </span>
                  </div>
                </div>
              );
            })
          ) : (
            <div className="p-8 text-center text-xs text-slate-400 space-y-2">
              <MessageSquare className="w-8 h-8 mx-auto text-slate-600 mb-1 opacity-60" />
              <div className="font-semibold text-slate-300">لا توجد محادثات مطابقة</div>
              <p className="text-[11px] text-slate-500 max-w-[200px] mx-auto">
                بمجرد وصول أي رسالة جديدة عبر واتساب، ستظهر هنا فوراً في الوقت الحقيقي.
              </p>
            </div>
          )}
        </div>
      </div>

      {/* 2. Main Chat Workspace */}
      <div className={`flex-1 flex flex-col bg-slate-900/50 ${!selectedConvId ? 'hidden lg:flex' : 'flex'}`}>
        {selectedConv ? (
          <>
            {/* Chat Header */}
            <div className="p-3.5 sm:p-4 border-b border-slate-800 bg-slate-900/90 flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                {/* Mobile Back Button to return to conversation list */}
                <button
                  onClick={() => setSelectedConvId(null)}
                  className="p-1.5 rounded-xl bg-slate-800 text-slate-300 hover:text-white lg:hidden flex items-center gap-1 text-xs"
                  title="العودة لقائمة المحادثات"
                >
                  <ArrowRight className="w-4 h-4" />
                  <span className="text-[11px] font-bold">القائمة</span>
                </button>

                <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-gradient-to-tr from-emerald-500 to-teal-400 text-slate-950 font-extrabold flex items-center justify-center text-sm shadow-md shadow-emerald-500/20 shrink-0">
                  {selectedConv.customer_name ? selectedConv.customer_name.slice(0, 2) : 'عم'}
                </div>

                <div className="min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <h3 className="font-bold text-xs sm:text-sm text-white truncate">
                      {selectedConv.customer_name || 'عميل واتساب'}
                    </h3>
                    <LeadBadge status={selectedConv.lead_status || 'general'} size="sm" />
                    <HumanBadge
                      needsHuman={selectedConv.needs_human || (selectedConv.status === 'human' ? 1 : 0)}
                      size="sm"
                    />
                  </div>
                  <div className="flex items-center gap-2 text-[11px] text-slate-400 font-mono mt-0.5">
                    <span>+{selectedConv.customer_phone}</span>
                    <span>•</span>
                    <span className="text-emerald-400 font-sans">{selectedConv.customer_service || 'يمن بلاس'}</span>
                  </div>
                </div>
              </div>

              {/* Mode Toggles, Live Sync & WhatsApp Button */}
              <div className="flex items-center gap-2 flex-wrap">
                {/* Live Sync Badge */}
                <div
                  onClick={() => {
                    if (selectedConvId) {
                      loadMessages(selectedConvId, false);
                      onRefresh();
                    }
                  }}
                  className="px-2 py-1 rounded-lg bg-slate-950 border border-slate-800 text-[11px] text-emerald-400 flex items-center gap-1.5 cursor-pointer hover:bg-slate-900 transition-colors"
                  title="مزامنة حية للرسائل كل 3 ثوانٍ - انقر للتحديث الفوري"
                >
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                  <span className="hidden sm:inline">مباشر</span>
                  <RefreshCw className="w-3 h-3 text-slate-500 hover:text-emerald-400 transition-colors" />
                </div>

                <div className="p-1 rounded-xl bg-slate-950 border border-slate-800 flex items-center gap-1 text-xs">
                  <button
                    onClick={() => handleToggleStatus('bot')}
                    className={`flex items-center gap-1 px-2.5 py-1 rounded-lg font-medium transition-colors ${
                      selectedConv.status === 'bot'
                        ? 'bg-emerald-600 text-white shadow-sm'
                        : 'text-slate-400 hover:text-white'
                    }`}
                    title="الرد الذكي التلقائي بواسطة Gemini"
                  >
                    <Bot className="w-3.5 h-3.5" />
                    <span>Bot AI</span>
                  </button>

                  <button
                    onClick={() => handleToggleStatus('human')}
                    className={`flex items-center gap-1 px-2.5 py-1 rounded-lg font-medium transition-colors ${
                      selectedConv.status === 'human'
                        ? 'bg-rose-600 text-white shadow-sm'
                        : 'text-slate-400 hover:text-white'
                    }`}
                    title="إيقاف الذكاء الاصطناعي والرد يدويًا"
                  >
                    <User className="w-3.5 h-3.5" />
                    <span>بشري (Human)</span>
                  </button>
                </div>

                <a
                  href={waUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="p-1.5 sm:px-2.5 sm:py-1 rounded-xl bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-300 border border-emerald-500/30 text-xs flex items-center gap-1 transition-colors"
                  title="فتح في تطبيق واتساب"
                >
                  <Phone className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">واتساب</span>
                </a>
              </div>
            </div>

            {/* Status Alert Banner */}
            {selectedConv.status === 'human' || selectedConv.needs_human === 1 ? (
              <div className="bg-amber-950/70 border-b border-amber-500/30 px-4 py-2 flex flex-wrap items-center justify-between gap-2 text-xs">
                <div className="flex items-center gap-2 text-amber-200">
                  <AlertCircle className="w-4 h-4 text-amber-400 shrink-0" />
                  <span>
                    <strong>التدخل البشري مفعّل:</strong> البوت متوقف عن الرد على هذا العميل حتى يستلم المشرف المحادثة.
                  </span>
                </div>
                <Button
                  variant="success"
                  size="sm"
                  onClick={() => handleToggleStatus('bot')}
                  leftIcon={<Bot className="w-3.5 h-3.5" />}
                >
                  إعادة البوت للرد الآن
                </Button>
              </div>
            ) : (
              <div className="bg-emerald-950/40 border-b border-emerald-500/20 px-4 py-1.5 flex items-center justify-between text-[11px] text-emerald-300">
                <div className="flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                  <span>المساعد الذكي (Gemini) يتولى الرد التلقائي على هذا العميل</span>
                </div>
                <button
                  onClick={() => handleToggleStatus('human')}
                  className="text-slate-400 hover:text-amber-300 underline underline-offset-2 transition-colors"
                >
                  تحويل إلى تدخل بشري يدوي
                </button>
              </div>
            )}

            {/* Chat Messages Feed */}
            <div className="flex-1 overflow-y-auto p-4 lg:p-6 space-y-4">
              {isLoadingMessages ? (
                <div className="h-full flex items-center justify-center text-xs text-slate-400 gap-2">
                  <RefreshCw className="w-4 h-4 animate-spin text-emerald-400" />
                  <span>جاري تحميل الرسائل...</span>
                </div>
              ) : messages.length > 0 ? (
                messages.map((msg, index) => {
                  const isCustomer = msg.sender === 'customer';
                  const isAgent = msg.sender === 'agent';
                  const msgKey = msg.id ? `msg-${msg.id}` : `msg-${index}-${msg.created_at || Date.now()}`;

                  return (
                    <div
                      key={msgKey}
                      className={`flex flex-col ${isCustomer ? 'items-start' : 'items-end'}`}
                    >
                      <div className="flex items-center gap-1.5 text-[10px] text-slate-400 mb-1 px-1">
                        <span>
                          {isCustomer
                            ? selectedConv.customer_name || 'العميل'
                            : isAgent || msg.sender === 'agent'
                            ? 'المشرف (رد يدوي)'
                            : 'المساعد الذكي (Gemini)'}
                        </span>
                        <span>•</span>
                        <span>{formatMessageTime(msg.created_at)}</span>
                      </div>

                      <div
                        className={`max-w-[85%] sm:max-w-[75%] px-4 py-2.5 rounded-2xl text-xs leading-relaxed shadow-md ${
                          isCustomer
                            ? 'bg-slate-800 text-slate-100 rounded-tr-none border border-slate-700'
                            : isAgent || msg.sender === 'agent'
                            ? 'bg-blue-600 text-white rounded-tl-none font-medium'
                            : 'bg-emerald-950/90 text-emerald-100 rounded-tl-none border border-emerald-500/30'
                        }`}
                      >
                        {msg.audio_url && (
                          <div className="mb-2 p-2 rounded-xl bg-black/30 border border-slate-700/50 flex items-center gap-2">
                            <Volume2 className="w-4 h-4 text-emerald-400" />
                            <audio controls src={msg.audio_url} className="h-8 max-w-full" />
                          </div>
                        )}
                        <p className="whitespace-pre-wrap">
                          {msg.message || (msg as any).text || (msg as any).content || '...'}
                        </p>
                      </div>
                    </div>
                  );
                })
              ) : (
                <div className="h-full flex flex-col items-center justify-center text-slate-500 text-xs">
                  <MessageSquare className="w-8 h-8 mb-2 opacity-40" />
                  <span>لا توجد رسائل مسجلة</span>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>

            {/* WhatsApp Delivery Status Notice */}
            {whatsappNotice && (
              <div
                className={`px-4 py-2 text-xs flex items-center justify-between gap-2 border-t ${
                  whatsappNotice.type === 'success'
                    ? 'bg-emerald-950/80 border-emerald-500/30 text-emerald-300'
                    : 'bg-rose-950/80 border-rose-500/30 text-rose-300'
                }`}
              >
                <div className="flex items-center gap-2">
                  {whatsappNotice.type === 'success' ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  ) : (
                    <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
                  )}
                  <span>{whatsappNotice.text}</span>
                </div>
                <button
                  onClick={() => setWhatsappNotice(null)}
                  className="text-xs opacity-70 hover:opacity-100 px-2 py-0.5 rounded bg-black/20"
                >
                  إغلاق
                </button>
              </div>
            )}

            {/* Quick Canned Responses Bar & Instant AI Trigger */}
            <div className="px-3 sm:px-4 py-2 bg-slate-950/80 border-t border-slate-800 flex items-center justify-between gap-2 overflow-x-auto text-[11px]">
              <div className="flex items-center gap-2 shrink-0">
                <button
                  type="button"
                  onClick={handleTriggerAiReply}
                  disabled={isGeneratingAi}
                  className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold flex items-center gap-1.5 shadow-md shadow-emerald-950/50 transition-all disabled:opacity-50 text-xs"
                  title="توليد رد ذكي فوري بواسطة Gemini وإرساله لواتساب العميل"
                >
                  {isGeneratingAi ? (
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  ) : (
                    <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                  )}
                  <span>{isGeneratingAi ? 'جاري التوليد...' : '✨ رد البوت الآلي الآن'}</span>
                </button>
              </div>

              <div className="flex items-center gap-1.5 overflow-x-auto">
                <span className="text-slate-400 flex items-center gap-1 shrink-0 text-[10px]">
                  <Zap className="w-3 h-3 text-amber-400" /> نماذج:
                </span>
                <button
                  onClick={() =>
                    handleCannedReply(
                      'أهلاً وسهلاً بك في يمن بلاس! يسعدنا خدمتك، بإمكانك تصفح خدماتنا عبر الرابط: https://yemplus.com 🌷'
                    )
                  }
                  className="px-2 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 shrink-0 transition-colors text-[10px]"
                >
                  رابط الموقع
                </button>
                <button
                  onClick={() =>
                    handleCannedReply(
                      'أبشر ولا يهمك يا غالي، راجعت طلبك وسأقوم بتجهيز عرض السعر المناسب وتفاصيل التنفيذ لك حالاً 🙏'
                    )
                  }
                  className="px-2 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 shrink-0 transition-colors text-[10px]"
                >
                  تجهيز عرض السعر
                </button>
                <button
                  onClick={() =>
                    handleCannedReply(
                      'أهلاً بك، تم استلام ملفات المشروع وسيبدأ الفريق بالعمل مباشرة بإذن الله ✨'
                    )
                  }
                  className="px-2 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 shrink-0 transition-colors text-[10px]"
                >
                  بدء العمل
                </button>
              </div>
            </div>

            {/* Chat Input Bar */}
            <form onSubmit={handleSendMessage} className="p-3 bg-slate-900 border-t border-slate-800 flex items-center gap-2">
              <input
                type="text"
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                placeholder="اكتب ردك للعميل (سيتم إرساله كرسالة واتساب رسمية)..."
                className="flex-1 py-2.5 px-4 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
              />

              <Button
                type="submit"
                variant="primary"
                size="sm"
                disabled={!inputText.trim() || isSending}
                isLoading={isSending}
                rightIcon={<Send className="w-3.5 h-3.5 rotate-180" />}
              >
                إرسال
              </Button>
            </form>
          </>
        ) : (
          <EmptyState
            icon={MessageSquare}
            title="اختر محادثة من القائمة لعرض الرسائل"
            description="تستطيع مراقبة ردود الذكاء الاصطناعي على مدار الساعة أو تولي الرد يدويًا عند الحاجة."
          />
        )}
      </div>
    </div>
  );
};
