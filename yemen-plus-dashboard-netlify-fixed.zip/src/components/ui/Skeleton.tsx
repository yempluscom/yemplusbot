import React from 'react';

export const Skeleton: React.FC<{ className?: string }> = ({ className = 'h-4 w-full' }) => {
  return (
    <div
      className={`animate-pulse rounded-xl bg-slate-800/60 border border-slate-700/30 ${className}`}
    />
  );
};

export const TableSkeleton: React.FC<{ rows?: number }> = ({ rows = 5 }) => {
  return (
    <div className="space-y-3 w-full">
      <div className="h-10 bg-slate-800/70 rounded-xl w-full animate-pulse" />
      {Array.from({ length: rows }).map((_, i) => (
        <div
          key={i}
          className="h-16 bg-slate-900/60 border border-slate-800/60 rounded-xl w-full animate-pulse flex items-center px-4 gap-4"
        >
          <div className="w-9 h-9 rounded-full bg-slate-800 shrink-0" />
          <div className="space-y-2 flex-1">
            <div className="h-3.5 bg-slate-800 rounded w-1/3" />
            <div className="h-2.5 bg-slate-800/80 rounded w-1/4" />
          </div>
          <div className="h-6 w-20 bg-slate-800 rounded-full" />
          <div className="h-8 w-16 bg-slate-800 rounded-lg hidden sm:block" />
        </div>
      ))}
    </div>
  );
};

export const CardGridSkeleton: React.FC<{ count?: number }> = ({ count = 8 }) => {
  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
      {Array.from({ length: count }).map((_, i) => (
        <div
          key={i}
          className="h-32 p-5 rounded-2xl bg-slate-900/80 border border-slate-800/80 animate-pulse flex flex-col justify-between"
        >
          <div className="flex items-center justify-between">
            <div className="w-10 h-10 rounded-xl bg-slate-800" />
            <div className="w-16 h-3 bg-slate-800 rounded" />
          </div>
          <div className="space-y-1.5">
            <div className="h-7 w-20 bg-slate-800 rounded" />
            <div className="h-3 w-28 bg-slate-800/70 rounded" />
          </div>
        </div>
      ))}
    </div>
  );
};
