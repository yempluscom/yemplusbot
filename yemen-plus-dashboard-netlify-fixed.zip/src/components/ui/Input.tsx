import React from 'react';

export interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  error?: string;
  leftIcon?: React.ReactNode;
  rightIcon?: React.ReactNode;
}

export const Input: React.FC<InputProps> = ({
  label,
  error,
  leftIcon,
  rightIcon,
  className = '',
  id,
  ...props
}) => {
  const inputId = id || (label ? `input-${label.replace(/\s+/g, '-').toLowerCase()}` : undefined);

  return (
    <div className="w-full space-y-1.5 text-right">
      {label && (
        <label htmlFor={inputId} className="block text-xs font-semibold text-slate-300">
          {label}
        </label>
      )}
      <div className="relative flex items-center">
        {rightIcon && (
          <div className="absolute right-3.5 pointer-events-none text-slate-400 flex items-center justify-center">
            {rightIcon}
          </div>
        )}
        <input
          id={inputId}
          className={`w-full py-2.5 rounded-xl bg-slate-950/80 border text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/30 transition-all duration-200 ${
            rightIcon ? 'pr-10' : 'pr-3.5'
          } ${leftIcon ? 'pl-10' : 'pl-3.5'} ${
            error
              ? 'border-red-500/80 focus:border-red-500'
              : 'border-slate-800 focus:border-emerald-500/80'
          } ${className}`}
          {...props}
        />
        {leftIcon && (
          <div className="absolute left-3.5 text-slate-400 flex items-center justify-center">
            {leftIcon}
          </div>
        )}
      </div>
      {error && <p className="text-xs text-red-400 mt-1 font-medium">{error}</p>}
    </div>
  );
};
