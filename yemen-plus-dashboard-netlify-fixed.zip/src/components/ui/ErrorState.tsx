import React from 'react';
import { AlertTriangle, RotateCw } from 'lucide-react';
import { Button } from './Button';

export interface ErrorStateProps {
  title?: string;
  message?: string;
  onRetry?: () => void;
}

export const ErrorState: React.FC<ErrorStateProps> = ({
  title = 'تعذر تحميل البيانات',
  message = 'حدث خطأ أثناء محاولة الاتصال بالخادم. يرجى المحاولة مرة أخرى.',
  onRetry,
}) => {
  return (
    <div className="p-8 text-center rounded-2xl bg-red-950/20 border border-red-500/30 flex flex-col items-center justify-center max-w-lg mx-auto my-6">
      <div className="w-12 h-12 rounded-2xl bg-red-500/20 text-red-400 border border-red-500/30 flex items-center justify-center mb-3.5">
        <AlertTriangle className="w-6 h-6" />
      </div>
      <h3 className="text-sm font-bold text-red-300 mb-1">{title}</h3>
      <p className="text-xs text-red-400/80 mb-4 max-w-sm">{message}</p>
      {onRetry && (
        <Button variant="danger" size="sm" onClick={onRetry} leftIcon={<RotateCw className="w-3.5 h-3.5" />}>
          إعادة المحاولة
        </Button>
      )}
    </div>
  );
};
