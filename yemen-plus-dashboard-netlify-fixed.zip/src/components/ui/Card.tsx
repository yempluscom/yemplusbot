import React from 'react';

export interface CardProps extends React.HTMLAttributes<HTMLDivElement> {
  hoverEffect?: boolean;
  padding?: 'none' | 'sm' | 'md' | 'lg';
}

export const Card: React.FC<CardProps> = ({
  children,
  hoverEffect = false,
  padding = 'md',
  className = '',
  ...props
}) => {
  const paddingClasses = {
    none: '',
    sm: 'p-3 sm:p-4',
    md: 'p-4 sm:p-6',
    lg: 'p-6 sm:p-8',
  }[padding];

  const hoverClasses = hoverEffect
    ? 'hover:border-slate-700/90 hover:bg-slate-900/95 transition-all duration-200 hover:shadow-xl hover:shadow-black/40'
    : '';

  return (
    <div
      className={`rounded-2xl bg-slate-900/90 border border-slate-800/80 backdrop-blur-xl ${paddingClasses} ${hoverClasses} ${className}`}
      {...props}
    >
      {children}
    </div>
  );
};
