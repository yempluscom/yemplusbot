import React from 'react';
import { LeadStatus, RequestStatus, RequestPriority, ConversationStatus } from '../../types';
import { Flame, Sun, Snowflake, Compass, AlertCircle, CheckCircle2, Clock, Bot, User, Ban } from 'lucide-react';

interface LeadBadgeProps {
  status: LeadStatus;
  size?: 'sm' | 'md';
}

export const LeadBadge: React.FC<LeadBadgeProps> = ({ status, size = 'md' }) => {
  const sizeClasses = size === 'sm' ? 'text-xs px-2 py-0.5' : 'text-xs font-semibold px-2.5 py-1';

  switch (status) {
    case 'hot':
      return (
        <span className={`inline-flex items-center gap-1 rounded-full bg-rose-500/15 text-rose-400 border border-rose-500/30 ${sizeClasses}`}>
          <Flame className="w-3.5 h-3.5 text-rose-500 animate-pulse" />
          <span>حار (Hot)</span>
        </span>
      );
    case 'warm':
      return (
        <span className={`inline-flex items-center gap-1 rounded-full bg-amber-500/15 text-amber-400 border border-amber-500/30 ${sizeClasses}`}>
          <Sun className="w-3.5 h-3.5 text-amber-500" />
          <span>مهتم (Warm)</span>
        </span>
      );
    case 'cold':
      return (
        <span className={`inline-flex items-center gap-1 rounded-full bg-slate-500/15 text-slate-400 border border-slate-500/30 ${sizeClasses}`}>
          <Snowflake className="w-3.5 h-3.5 text-slate-400" />
          <span>بارد (Cold)</span>
        </span>
      );
    case 'general':
    default:
      return (
        <span className={`inline-flex items-center gap-1 rounded-full bg-blue-500/15 text-blue-400 border border-blue-500/30 ${sizeClasses}`}>
          <Compass className="w-3.5 h-3.5 text-blue-400" />
          <span>عام (General)</span>
        </span>
      );
  }
};

interface RequestStatusBadgeProps {
  status: RequestStatus;
  size?: 'sm' | 'md';
}

export const RequestStatusBadge: React.FC<RequestStatusBadgeProps> = ({ status, size = 'md' }) => {
  const sizeClasses = size === 'sm' ? 'text-xs px-2 py-0.5' : 'text-xs font-semibold px-2.5 py-1';

  switch (status) {
    case 'new':
      return (
        <span className={`inline-flex items-center gap-1 rounded-full bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 ${sizeClasses}`}>
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping"></span>
          <span>طلب جديد</span>
        </span>
      );
    case 'in_progress':
      return (
        <span className={`inline-flex items-center gap-1 rounded-full bg-indigo-500/15 text-indigo-400 border border-indigo-500/30 ${sizeClasses}`}>
          <Clock className="w-3.5 h-3.5 text-indigo-400" />
          <span>قيد التنفيذ</span>
        </span>
      );
    case 'completed':
      return (
        <span className={`inline-flex items-center gap-1 rounded-full bg-teal-500/15 text-teal-400 border border-teal-500/30 ${sizeClasses}`}>
          <CheckCircle2 className="w-3.5 h-3.5 text-teal-400" />
          <span>مكتمل</span>
        </span>
      );
    case 'closed':
    default:
      return (
        <span className={`inline-flex items-center gap-1 rounded-full bg-slate-500/15 text-slate-400 border border-slate-500/30 ${sizeClasses}`}>
          <Ban className="w-3.5 h-3.5 text-slate-400" />
          <span>مغلق</span>
        </span>
      );
  }
};

interface PriorityBadgeProps {
  priority: RequestPriority;
  size?: 'sm' | 'md';
}

export const PriorityBadge: React.FC<PriorityBadgeProps> = ({ priority, size = 'md' }) => {
  const sizeClasses = size === 'sm' ? 'text-xs px-2 py-0.5' : 'text-xs font-semibold px-2.5 py-1';

  if (priority === 'high') {
    return (
      <span className={`inline-flex items-center gap-1 rounded-md bg-rose-500/20 text-rose-300 border border-rose-500/40 ${sizeClasses}`}>
        <AlertCircle className="w-3 h-3 text-rose-400" />
        <span>أولوية عاجلة</span>
      </span>
    );
  }

  return (
    <span className={`inline-flex items-center gap-1 rounded-md bg-slate-800 text-slate-300 border border-slate-700 ${sizeClasses}`}>
      <span>عادية</span>
    </span>
  );
};

interface HumanBadgeProps {
  needsHuman: boolean | number;
  size?: 'sm' | 'md';
}

export const HumanBadge: React.FC<HumanBadgeProps> = ({ needsHuman, size = 'md' }) => {
  const isHuman = needsHuman === true || needsHuman === 1;
  const sizeClasses = size === 'sm' ? 'text-xs px-2 py-0.5' : 'text-xs font-bold px-2.5 py-1';

  if (!isHuman) return null;

  return (
    <span className={`inline-flex items-center gap-1 rounded-full bg-red-600 text-white shadow-sm shadow-red-900/50 animate-bounce ${sizeClasses}`}>
      <AlertCircle className="w-3.5 h-3.5 text-white" />
      <span>يحتاج تدخل بشري</span>
    </span>
  );
};

interface ConversationBadgeProps {
  status: ConversationStatus;
  size?: 'sm' | 'md';
}

export const ConversationBadge: React.FC<ConversationBadgeProps> = ({ status, size = 'md' }) => {
  const sizeClasses = size === 'sm' ? 'text-xs px-2 py-0.5' : 'text-xs font-medium px-2.5 py-1';

  switch (status) {
    case 'human':
      return (
        <span className={`inline-flex items-center gap-1 rounded-full bg-rose-500/15 text-rose-300 border border-rose-500/30 ${sizeClasses}`}>
          <User className="w-3.5 h-3.5 text-rose-400" />
          <span>بشري (Human)</span>
        </span>
      );
    case 'bot':
      return (
        <span className={`inline-flex items-center gap-1 rounded-full bg-emerald-500/15 text-emerald-300 border border-emerald-500/30 ${sizeClasses}`}>
          <Bot className="w-3.5 h-3.5 text-emerald-400" />
          <span>ذكاء اصطناعي (Bot)</span>
        </span>
      );
    case 'closed':
    default:
      return (
        <span className={`inline-flex items-center gap-1 rounded-full bg-slate-500/15 text-slate-400 border border-slate-500/30 ${sizeClasses}`}>
          <Ban className="w-3.5 h-3.5 text-slate-400" />
          <span>منتهية</span>
        </span>
      );
  }
};
