import React from 'react';
import { Button } from './Button';

export interface EmptyStateProps {
  icon: React.ElementType;
  title: string;
  description: string;
  actionLabel?: string;
  onAction?: () => void;
  iconColor?: string;
}

export const EmptyState: React.FC<EmptyStateProps> = ({
  icon: Icon,
  title,
  description,
  actionLabel,
  onAction,
  iconColor = 'text-slate-400',
}) => {
  return (
    <div className="py-14 px-4 text-center flex flex-col items-center justify-center rounded-2xl bg-slate-900/40 border border-dashed border-slate-800 my-4 max-w-xl mx-auto">
      <div className="w-14 h-14 rounded-2xl bg-slate-800/80 border border-slate-700/60 flex items-center justify-center mb-4 text-slate-300 shadow-inner">
        <Icon className={`w-7 h-7 ${iconColor}`} />
      </div>
      <h3 className="text-base font-bold text-slate-200 mb-1.5">{title}</h3>
      <p className="text-xs text-slate-400 max-w-md mb-5 leading-relaxed">{description}</p>
      {actionLabel && onAction && (
        <Button variant="secondary" size="sm" onClick={onAction}>
          {actionLabel}
        </Button>
      )}
    </div>
  );
};
