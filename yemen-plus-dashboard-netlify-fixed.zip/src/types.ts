export type LeadStatus = 'hot' | 'warm' | 'cold' | 'general';

export type ConversationStatus = 'bot' | 'human' | 'closed';

export type RequestStatus = 'new' | 'in_progress' | 'completed' | 'closed';

export type RequestPriority = 'normal' | 'high';

export type MessageSender = 'customer' | 'assistant' | 'agent' | 'system';

export type MessageType = 'text' | 'audio' | 'image' | 'document';

export interface Customer {
  id: number;
  phone: string;
  name: string | null;
  service: string | null;
  business: string | null;
  project: string | null;
  goal: string | null;
  budget: string | null;
  timeline: string | null;
  lead_status: LeadStatus;
  needs_human: boolean | number;
  created_at: string;
  updated_at: string;
  total_requests?: number;
  total_messages?: number;
  last_active?: string;
}

export interface Conversation {
  id: number;
  customer_id: number;
  status: ConversationStatus;
  last_message: string | null;
  last_message_at: string | null;
  created_at: string;
  updated_at: string;
  // Augmented fields
  customer_name?: string | null;
  customer_phone?: string;
  customer_service?: string | null;
  lead_status?: LeadStatus;
  needs_human?: boolean | number;
  unread_count?: number;
}

export interface Message {
  id: number;
  conversation_id: number;
  sender: MessageSender;
  message: string;
  message_type: MessageType;
  created_at: string;
  media_url?: string | null;
  is_audio?: boolean;
}

export interface RequestItem {
  id: number;
  customer_id: number;
  conversation_id?: number | null;
  service: string | null;
  details: string | {
    business?: string | null;
    project?: string | null;
    goal?: string | null;
    budget?: string | null;
    timeline?: string | null;
    needs_human?: boolean;
    notes?: string | null;
  };
  status: RequestStatus;
  priority: RequestPriority;
  created_at: string;
  updated_at: string;
  // Augmented
  customer_name?: string | null;
  customer_phone?: string;
  lead_status?: LeadStatus;
  needs_human?: boolean | number;
  parsed_details?: {
    business?: string | null;
    project?: string | null;
    goal?: string | null;
    budget?: string | null;
    timeline?: string | null;
    needs_human?: boolean;
    notes?: string | null;
  };
}

export interface DashboardStats {
  totalCustomers: number;
  newCustomersToday: number;
  activeConversations: number;
  newRequests: number;
  followUpRequests: number;
  hotLeadsCount: number;
  warmLeadsCount: number;
  humanRequestsCount: number;
  completedRequestsCount: number;
  servicesBreakdown: { service: string; count: number; percentage: number }[];
  leadsBreakdown: { status: LeadStatus; count: number; label: string; color: string }[];
  weeklyTrends: { day: string; customers: number; requests: number; humanRequests: number }[];
}

export interface AnalyticsData {
  summary: {
    totalCustomers: number;
    totalConversations: number;
    totalRequests: number;
    hotLeads: number;
    warmLeads: number;
    humanRequests: number;
    conversionRate: number;
    avgResponseMinutes: number;
  };
  servicesDemand: { service: string; count: number; revenueEstimate?: string }[];
  dailyGrowth: { date: string; customers: number; requests: number; hotLeads: number }[];
  leadFunnel: { stage: string; count: number; percentage: number }[];
  hourlyActivity: { hour: string; messages: number }[];
  satisfactionRate: number;
}

export interface WorkerConnectionConfig {
  workerUrl: string;
  apiKey: string;
  isConfigured: boolean;
  isConnected: boolean;
  lastPing?: string;
  pingStatus?: 'success' | 'error' | 'pending' | 'idle';
  errorMessage?: string;
}

export type ActiveTab =
  | 'dashboard'
  | 'customers'
  | 'customer-details'
  | 'conversations'
  | 'requests'
  | 'leads'
  | 'human-requests'
  | 'analytics'
  | 'settings';
