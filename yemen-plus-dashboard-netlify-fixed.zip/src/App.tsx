import React, { useState, useEffect } from 'react';
import {
  ActiveTab,
  DashboardStats,
  Customer,
  Conversation,
  RequestItem,
  AnalyticsData,
} from './types';
import { api } from './lib/api';
import { AuthProvider, useAuth } from './lib/auth';
import { LoginPage } from './components/auth/LoginPage';
import { Sidebar } from './components/layout/Sidebar';
import { Header } from './components/layout/Header';
import { StatCards } from './components/dashboard/StatCards';
import { OverviewCharts } from './components/dashboard/OverviewCharts';
import { QuickHumanHandoff } from './components/dashboard/QuickHumanHandoff';
import { CustomerList } from './components/customers/CustomerList';
import { CustomerDetailView } from './components/customers/CustomerDetailView';
import { ConversationHub } from './components/conversations/ConversationHub';
import { RequestsBoard } from './components/requests/RequestsBoard';
import { HumanRequestsQueue } from './components/human/HumanRequestsQueue';
import { LeadsPipeline } from './components/leads/LeadsPipeline';
import { AnalyticsView } from './components/analytics/AnalyticsView';
import { SettingsView } from './components/settings/SettingsView';
import { CardGridSkeleton } from './components/ui/Skeleton';
import { Sparkles, RotateCw } from 'lucide-react';

function DashboardApp() {
  const { isAuthenticated, isLoading: isAuthLoading } = useAuth();
  const [activeTab, setActiveTab] = useState<ActiveTab>('dashboard');
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [isWorkerLive, setIsWorkerLive] = useState(false);

  // Core Data States
  const [stats, setStats] = useState<DashboardStats | null>(null);

  const defaultStats: DashboardStats = {
    totalCustomers: 0,
    newCustomersToday: 0,
    activeConversations: 0,
    newRequests: 0,
    followUpRequests: 0,
    hotLeadsCount: 0,
    warmLeadsCount: 0,
    humanRequestsCount: 0,
    completedRequestsCount: 0,
    servicesBreakdown: [],
    leadsBreakdown: [],
    weeklyTrends: [
      { day: 'السبت', customers: 0, requests: 0, humanRequests: 0 },
      { day: 'الأحد', customers: 0, requests: 0, humanRequests: 0 },
      { day: 'الإثنين', customers: 0, requests: 0, humanRequests: 0 },
      { day: 'الثلاثاء', customers: 0, requests: 0, humanRequests: 0 },
      { day: 'الأربعاء', customers: 0, requests: 0, humanRequests: 0 },
      { day: 'الخميس', customers: 0, requests: 0, humanRequests: 0 },
      { day: 'الجمعة', customers: 0, requests: 0, humanRequests: 0 },
    ],
  };

  const currentStats = stats || defaultStats;
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [requests, setRequests] = useState<RequestItem[]>([]);
  const [humanRequests, setHumanRequests] = useState<any[]>([]);
  const [analytics, setAnalytics] = useState<AnalyticsData | null>(null);

  // Selected entities for deep view
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);
  const [targetConversationId, setTargetConversationId] = useState<number | null>(null);

  const fetchAllData = async () => {
    if (!isAuthenticated) return;
    setIsLoading(true);
    try {
      const [
        statsData,
        customersData,
        conversationsData,
        requestsData,
        humanData,
        analyticsData,
      ] = await Promise.all([
        api.getDashboardStats().catch(() => null),
        api.getCustomers().catch(() => []),
        api.getConversations().catch(() => []),
        api.getRequests().catch(() => []),
        api.getHumanRequests().catch(() => []),
        api.getAnalytics().catch(() => null),
      ]);

      if (statsData) setStats(statsData);
      setCustomers(customersData);
      setConversations(conversationsData);
      setRequests(requestsData);
      setHumanRequests(humanData);
      if (analyticsData) setAnalytics(analyticsData);
    } catch (err) {
      console.error('Error fetching dashboard data:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (isAuthenticated) {
      fetchAllData();
    }
  }, [isAuthenticated]);

  // If Auth is verifying session
  if (isAuthLoading) {
    return (
      <div className="min-h-screen min-h-[100dvh] w-full bg-slate-950 flex flex-col items-center justify-center p-4">
        <div className="flex flex-col items-center gap-4 text-center">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-emerald-600 to-teal-500 p-0.5 shadow-xl shadow-emerald-900/40 animate-pulse">
            <div className="w-full h-full bg-slate-950 rounded-[14px] flex items-center justify-center">
              <Sparkles className="w-8 h-8 text-emerald-400" />
            </div>
          </div>
          <div className="space-y-1">
            <h2 className="text-lg font-bold text-white">يمن بلاس | Yemen Plus</h2>
            <p className="text-xs text-slate-400 flex items-center justify-center gap-1.5">
              <RotateCw className="w-3.5 h-3.5 animate-spin text-emerald-400" />
              <span>جاري التحقق من الجلسة الآمنة...</span>
            </p>
          </div>
        </div>
      </div>
    );
  }

  // If unauthenticated, display Login Page
  if (!isAuthenticated) {
    return <LoginPage />;
  }

  const handleOpenCustomer = (customer: Customer) => {
    setSelectedCustomer(customer);
    setActiveTab('customer-details');
  };

  const handleOpenCustomerById = (customerId: number) => {
    const cust = customers.find((c) => c.id === customerId);
    if (cust) {
      setSelectedCustomer(cust);
      setActiveTab('customer-details');
    }
  };

  const handleOpenConversation = (conversationId: number) => {
    setTargetConversationId(conversationId);
    setActiveTab('conversations');
  };

  const handleCustomerUpdated = (updated: Customer) => {
    setCustomers((prev) => prev.map((c) => (c.id === updated.id ? updated : c)));
    if (selectedCustomer?.id === updated.id) {
      setSelectedCustomer(updated);
    }
    fetchAllData();
  };

  const handleResolveHuman = async (customerId: number) => {
    try {
      await api.resolveHumanRequest(customerId);
      fetchAllData();
    } catch (err) {
      console.error('Error resolving request:', err);
    }
  };

  return (
    <div className="min-h-screen min-h-[100dvh] bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-emerald-500 selection:text-white">
      {/* Sidebar Navigation */}
      <Sidebar
        activeTab={activeTab}
        setActiveTab={(tab) => {
          if (tab !== 'customer-details') setSelectedCustomer(null);
          setActiveTab(tab);
        }}
        stats={currentStats}
        isWorkerLive={isWorkerLive}
        isOpen={sidebarOpen}
        setIsOpen={setSidebarOpen}
      />

      {/* Main Content Area */}
      <div className="lg:mr-72 flex-1 flex flex-col min-w-0 transition-all duration-300">
        <Header
          activeTab={activeTab}
          onToggleSidebar={() => setSidebarOpen(!sidebarOpen)}
          onRefresh={fetchAllData}
          isLoading={isLoading}
          stats={currentStats}
          onOpenHumanQueue={() => setActiveTab('human-requests')}
          onNavigateToSettings={() => setActiveTab('settings')}
        />

        <main className="flex-1 p-3.5 sm:p-6 lg:p-8 max-w-7xl w-full mx-auto space-y-6">
          {/* TAB 1: Dashboard Overview */}
          {activeTab === 'dashboard' && (
            <div className="space-y-6">
              {/* Quick Urgent Human Handoff Notification if any */}
              <QuickHumanHandoff
                humanRequests={humanRequests}
                onOpenConversation={handleOpenConversation}
                onOpenCustomer={handleOpenCustomerById}
                onResolve={handleResolveHuman}
                onNavigateToHumanTab={() => setActiveTab('human-requests')}
              />

              {/* Stat Cards */}
              {isLoading && !stats ? (
                <CardGridSkeleton count={8} />
              ) : (
                <StatCards stats={currentStats} onNavigate={setActiveTab} />
              )}

              {/* Charts & Analytics Breakdown */}
              <OverviewCharts stats={currentStats} />
            </div>
          )}

          {/* TAB 2: Customers */}
          {activeTab === 'customers' && (
            <CustomerList
              customers={customers}
              onSelectCustomer={handleOpenCustomer}
              onOpenChat={handleOpenCustomerById}
            />
          )}

          {/* TAB 2.1: Customer Detail View */}
          {activeTab === 'customer-details' && selectedCustomer && (
            <CustomerDetailView
              customer={selectedCustomer}
              onBack={() => {
                setSelectedCustomer(null);
                setActiveTab('customers');
              }}
              onOpenConversation={handleOpenConversation}
              onCustomerUpdated={handleCustomerUpdated}
            />
          )}

          {/* TAB 3: Conversations */}
          {activeTab === 'conversations' && (
            <ConversationHub
              conversations={conversations}
              initialConversationId={targetConversationId}
              onRefresh={fetchAllData}
            />
          )}

          {/* TAB 4: Requests */}
          {activeTab === 'requests' && (
            <RequestsBoard
              requests={requests}
              onRefresh={fetchAllData}
              onOpenConversation={handleOpenConversation}
              onOpenCustomer={handleOpenCustomerById}
            />
          )}

          {/* TAB 5: Human Requests */}
          {activeTab === 'human-requests' && (
            <HumanRequestsQueue
              humanRequests={humanRequests}
              onRefresh={fetchAllData}
              onOpenConversation={handleOpenConversation}
              onOpenCustomer={handleOpenCustomerById}
            />
          )}

          {/* TAB 6: Leads Pipeline */}
          {activeTab === 'leads' && (
            <LeadsPipeline
              customers={customers}
              onOpenCustomer={handleOpenCustomer}
              onOpenChat={handleOpenCustomerById}
            />
          )}

          {/* TAB 7: Analytics */}
          {activeTab === 'analytics' && analytics && (
            <AnalyticsView data={analytics} />
          )}

          {/* TAB 8: Settings & Integration */}
          {activeTab === 'settings' && (
            <SettingsView onConnectionTested={() => setIsWorkerLive(true)} />
          )}
        </main>

        {/* Global Footer */}
        <footer className="mt-auto border-t border-slate-800/80 py-4 px-6 text-center text-xs text-slate-400 flex flex-col sm:flex-row items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <span className="font-bold text-slate-300">يمن بلاس (Yemen Plus)</span>
            <span>•</span>
            <span>نظام إدارة خدمة العملاء والمبيعات الذكية</span>
          </div>
          <div className="flex items-center gap-3">
            <span className="text-slate-400 font-mono text-[11px]">Gemini 3.7 Flash + Cloudflare D1 + Munsit AI</span>
          </div>
        </footer>
      </div>
    </div>
  );
}

export function App() {
  return (
    <AuthProvider>
      <DashboardApp />
    </AuthProvider>
  );
}

export default App;
