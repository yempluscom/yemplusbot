/**
 * ============================================================================
 * Netlify Serverless API Function for Yemen Plus Dashboard
 * ============================================================================
 * Handles server-side API routing and secure proxying to Cloudflare Worker
 * when deployed to Netlify, ensuring all secrets remain protected on the server.
 * ============================================================================
 */

interface HandlerEvent {
  path: string;
  httpMethod: string;
  headers: Record<string, string | undefined>;
  queryStringParameters?: Record<string, string | undefined>;
  body?: string | null;
  isBase64Encoded?: boolean;
}

interface HandlerResponse {
  statusCode: number;
  headers?: Record<string, string>;
  body: string;
}


import crypto from "node:crypto";

const ADMIN_EMAIL = (process.env.ADMIN_EMAIL || "admin@yemplus.com").trim().toLowerCase();
const ADMIN_USERNAME = (process.env.ADMIN_USERNAME || "admin").trim().toLowerCase();
const ADMIN_PASSWORD = (process.env.ADMIN_PASSWORD || "").trim();
const AUTH_SECRET = (process.env.AUTH_SECRET || "").trim();

function signToken(payload: Record<string, any>): string {
  const dataStr = Buffer.from(JSON.stringify(payload)).toString("base64url");
  const signature = crypto.createHmac("sha256", AUTH_SECRET).update(dataStr).digest("base64url");
  return `${dataStr}.${signature}`;
}

function verifyToken(token: string): any | null {
  if (!AUTH_SECRET || !token || !token.includes(".")) return null;
  const [dataStr, signature] = token.split(".");
  if (!dataStr || !signature) return null;
  const expected = crypto.createHmac("sha256", AUTH_SECRET).update(dataStr).digest("base64url");
  if (signature !== expected) return null;
  try {
    const payload = JSON.parse(Buffer.from(dataStr, "base64url").toString("utf8"));
    if (payload.exp && Date.now() > payload.exp) return null;
    return payload;
  } catch { return null; }
}

function getCookieToken(event: HandlerEvent): string | null {
  const cookie = event.headers.cookie || event.headers.Cookie || "";
  for (const part of cookie.split(";")) {
    const item = part.trim();
    if (item.startsWith("yemplus_session=")) return item.substring("yemplus_session=".length);
  }
  const auth = event.headers.authorization || event.headers.Authorization || "";
  if (auth.startsWith("Bearer ")) return auth.substring(7).trim();
  return null;
}

function getSession(event: HandlerEvent): any | null {
  const token = getCookieToken(event);
  return token ? verifyToken(token) : null;
}

function authUserResponse(session: any) {
  return {
    name: session.name || "إدارة يمن بلاس",
    email: session.email || ADMIN_EMAIL,
    username: session.username || ADMIN_USERNAME,
    role: session.role || "admin"
  };
}

function cleanSecret(val?: string): string {
  if (!val) return "";
  let clean = val.trim();
  if (clean.startsWith("DASHBOARD_API_KEY=")) {
    clean = clean.substring("DASHBOARD_API_KEY=".length).trim();
  }
  if ((clean.startsWith('"') && clean.endsWith('"')) || (clean.startsWith("'") && clean.endsWith("'"))) {
    clean = clean.slice(1, -1).trim();
  }
  return clean;
}

export const handler = async (event: HandlerEvent): Promise<HandlerResponse> => {
  // CORS Preflight
  if (event.httpMethod === "OPTIONS") {
    return {
      statusCode: 204,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "GET, POST, PATCH, PUT, DELETE, OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Dashboard-Key"
      },
      body: ""
    };
  }

  const workerUrl = (process.env.WORKER_API_URL || "https://whatsapp-gemini-webhook.abdulmalikgd.workers.dev").trim().replace(/\/$/, "");
  const dashboardApiKey = cleanSecret(process.env.DASHBOARD_API_KEY);

  // Extract path: remove /.netlify/functions/api or /api prefix
  let apiPath = event.path;
  if (apiPath.startsWith("/.netlify/functions/api")) {
    apiPath = apiPath.substring("/.netlify/functions/api".length);
  }
  if (!apiPath.startsWith("/")) {
    apiPath = "/" + apiPath;
  }
  if (!apiPath.startsWith("/api")) {
    apiPath = "/api" + apiPath;
  }

  // Construct query string if present
  let queryString = "";
  if (event.queryStringParameters && Object.keys(event.queryStringParameters).length > 0) {
    const params = new URLSearchParams();
    for (const [key, value] of Object.entries(event.queryStringParameters)) {
      if (value !== undefined) {
        params.append(key, value);
      }
    }
    queryString = `?${params.toString()}`;
  }

  // Authentication endpoints are handled here on Netlify (not forwarded to Worker)
  if (apiPath === "/api/auth/login" && event.httpMethod === "POST") {
    let body: any = {};
    try { body = event.body ? JSON.parse(event.body) : {}; } catch { body = {}; }
    const identifier = String(body.email || body.username || "").trim().toLowerCase();
    const inputPassword = String(body.password || "").trim();

    if (!identifier || !inputPassword) {
      return { statusCode: 400, headers: { "Content-Type": "application/json" }, body: JSON.stringify({ success: false, error: "يرجى إدخال اسم المستخدم/البريد الإلكتروني وكلمة المرور" }) };
    }

    const allowedUsers = [ADMIN_EMAIL, ADMIN_USERNAME, "admin@yemplus.com", "admin"].filter(Boolean);
    const isValidUser = allowedUsers.includes(identifier);
    const isValidPassword = Boolean(ADMIN_PASSWORD) && inputPassword === ADMIN_PASSWORD;

    if (!AUTH_SECRET) {
      return { statusCode: 500, headers: { "Content-Type": "application/json" }, body: JSON.stringify({ success: false, error: "AUTH_SECRET غير مضبوط في Netlify Environment Variables" }) };
    }

    if (!isValidUser || !isValidPassword) {
      return { statusCode: 401, headers: { "Content-Type": "application/json" }, body: JSON.stringify({ success: false, error: "بيانات الدخول غير صحيحة" }) };
    }

    const sessionData = {
      userId: 1, email: ADMIN_EMAIL, username: ADMIN_USERNAME, name: "إدارة يمن بلاس", role: "admin",
      exp: Date.now() + 7 * 24 * 60 * 60 * 1000
    };
    const token = signToken(sessionData);
    return {
      statusCode: 200,
      headers: {
        "Content-Type": "application/json",
        "Set-Cookie": `yemplus_session=${token}; Path=/; Max-Age=${7 * 24 * 3600}; HttpOnly; SameSite=Lax`
      },
      body: JSON.stringify({ success: true, token, user: authUserResponse(sessionData) })
    };
  }

  if (apiPath === "/api/auth/me" && event.httpMethod === "GET") {
    const session = getSession(event);
    return {
      statusCode: 200,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(session ? { authenticated: true, user: authUserResponse(session) } : { authenticated: false })
    };
  }

  if (apiPath === "/api/auth/logout" && event.httpMethod === "POST") {
    return {
      statusCode: 200,
      headers: {
        "Content-Type": "application/json",
        "Set-Cookie": "yemplus_session=; Path=/; Max-Age=0; HttpOnly; SameSite=Lax"
      },
      body: JSON.stringify({ success: true, message: "تم تسجيل الخروج بنجاح" })
    };
  }

  // Protect all other API endpoints with the Dashboard session
  if (apiPath.startsWith("/api") && apiPath !== "/api/health" && apiPath !== "/api/worker/ping") {
    const session = getSession(event);
    if (!session) {
      return {
        statusCode: 401,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ error: "غير مصرح - يرجى تسجيل الدخول أولاً", code: "UNAUTHORIZED" })
      };
    }
  }

  // Health endpoint on Netlify
  if (apiPath === "/api/health" && event.httpMethod === "GET") {
    return {
      statusCode: 200,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        status: "ok",
        platform: "Netlify Functions",
        worker_configured: Boolean(workerUrl),
        key_configured: Boolean(dashboardApiKey),
        timestamp: new Date().toISOString()
      })
    };
  }

  // Worker Ping Endpoint
  if (apiPath === "/api/worker/ping" && event.httpMethod === "POST") {
    try {
      const targetUrl = `${workerUrl}/api/health`;
      const forwardHeaders: Record<string, string> = {
        "Accept": "application/json"
      };

      if (dashboardApiKey) {
        forwardHeaders["Authorization"] = `Bearer ${dashboardApiKey}`;
        forwardHeaders["X-Dashboard-Key"] = dashboardApiKey;
      }

      const response = await fetch(targetUrl, {
        method: "GET",
        headers: forwardHeaders
      });

      const data = await response.json().catch(() => ({}));

      return {
        statusCode: response.status,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          success: response.ok,
          status: response.status,
          message: response.ok ? "الاتصال بالـ Cloudflare Worker ناجح" : "فشل التحقق من مفتاح API في Cloudflare Worker",
          data,
          workerUrl
        })
      };
    } catch (err: any) {
      return {
        statusCode: 500,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          success: false,
          error: `فشل الاتصال: ${err?.message || "خطأ في الشبكة"}`
        })
      };
    }
  }

  // Forward all other requests to Cloudflare Worker
  try {
    const targetUrl = `${workerUrl}${apiPath}${queryString}`;
    const forwardHeaders: Record<string, string> = {
      "Content-Type": "application/json",
      "Accept": "application/json"
    };

    if (dashboardApiKey) {
      forwardHeaders["Authorization"] = `Bearer ${dashboardApiKey}`;
      forwardHeaders["X-Dashboard-Key"] = dashboardApiKey;
    }

    const fetchOptions: RequestInit = {
      method: event.httpMethod,
      headers: forwardHeaders
    };

    if (["POST", "PATCH", "PUT"].includes(event.httpMethod) && event.body) {
      fetchOptions.body = event.body;
    }

    const response = await fetch(targetUrl, fetchOptions);
    const contentType = response.headers.get("content-type") || "application/json";
    const bodyText = await response.text();

    return {
      statusCode: response.status,
      headers: {
        "Content-Type": contentType,
        "Access-Control-Allow-Origin": "*"
      },
      body: bodyText
    };
  } catch (error: any) {
    return {
      statusCode: 502,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        error: "Bad Gateway",
        message: "تعذر تمرير الطلب إلى Cloudflare Worker",
        details: error?.message || error
      })
    };
  }
};
